#!/bin/bash
make
./game

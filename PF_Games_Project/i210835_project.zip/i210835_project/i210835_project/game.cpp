
/*

  MUHAMMAD ABDULLAH KHAN
  21I-0835
  BS(CS)
  
*/


#ifndef RushHour_CPP_
#define RushHour_CPP_
#include "util.h"
#include <iostream>
#include<string>
#include<cmath> 
// for basic math functions such as cos, sin, sqrt
using namespace std;


 int score=0;
 
void SetCanvasSize(int width, int height) {
	glMatrixMode (GL_PROJECTION);
	glLoadIdentity();
	glOrtho(0, width, 0, height, -1, 1); // set the screen size to given width and height.
	glMatrixMode (GL_MODELVIEW);
	glLoadIdentity();
}


int xI = 40, yI = 900;

void drawCaryellow()                                          // draws yellow car

 {
	
DrawRectangle( xI+1, yI+3 , 40 , 20 , colors[BLACK] );	
DrawRectangle( xI-4, yI-5 , 63 , 20 , colors[GOLD] );
DrawSquare(xI+1,yI-10,15,colors[BLACK]);
DrawSquare(xI+33,yI-10,15,colors[BLACK]);
DrawSquare(xI+53,yI+2,6,colors[BLUE]);

	glutPostRedisplay();
               }

               
               
int i = 40, j = 900;

void drawCarred()                                          // draws red car
{
	
DrawRectangle( i+1, j+3 , 40 , 20 , colors[BLACK] );	
DrawRectangle( i-4, j-5 , 63 , 20 , colors[BROWN] );
DrawSquare(i+1,j-10,15,colors[BLACK]);
DrawSquare(i+33,j-10,15,colors[BLACK]);
DrawSquare(i+53,j+2,6,colors[BLUE]);

	glutPostRedisplay();
               }



int a = 270, b = 400;
void drawCar2()                                // bot car
                 {
DrawRectangle( a+1, b+3 , 40 , 20 , colors[BLACK] );	
DrawRectangle( a-4, b-5 , 63 , 20 , colors[OLD_LACE] );
DrawSquare(a+1,b-10,15,colors[BLACK]);
DrawSquare(a+33,b-10,15,colors[BLACK]);
DrawSquare(a+53,b+2,6,colors[BLUE]);

	glutPostRedisplay();
               }


int c=400,d=830;
void drawCar3()                          // bot car 2
                 {
DrawRectangle( c+1, d+3 , 40 , 20 , colors[BLACK] );	
DrawRectangle( c-4, d-5 , 63 , 20 , colors[SALMON] );
DrawSquare(c+1,d-10,15,colors[BLACK]);
DrawSquare(c+33,d-10,15,colors[BLACK]);
DrawSquare(c+53,d+2,6,colors[BLUE]);

	glutPostRedisplay();
               }
               
         int e=390,f=100;
void drawCar4()                 // bot car 3
                 {
DrawRectangle( e+1, f+3 , 40 , 20 , colors[BLACK] );	
DrawRectangle( e-4, f-5 , 63 , 20 , colors[DARK_BLUE] );
DrawSquare(e+1,f-10,15,colors[BLACK]);
DrawSquare(e+33,f-10,15,colors[BLACK]);
DrawSquare(e+53,f+2,6,colors[BLUE]);

	glutPostRedisplay();
               }      
               
          int g=800,h=630;
void drawCar5()                               // bot car 4
                 {
DrawRectangle( g+1, h+3 , 40 , 20 , colors[BLACK] );	
DrawRectangle( g-4, h-5 , 63 , 20 , colors[SALMON] );
DrawSquare(g+1,h-10,15,colors[BLACK]);
DrawSquare(g+33,h-10,15,colors[BLACK]);
DrawSquare(g+53,h+2,6,colors[BLUE]);

	glutPostRedisplay();
               }     
               
               
               
               
               
               
               
               
               
               
               
               
               
bool flag = true;
void moveCar() {                // function to move player's taxi yellow
	
	if (xI > 10 && flag) {
		xI -= 5;
		cout << "going left";
		if(xI < 100)
			
			flag = false;

	}
	else if (xI < 1010 && !flag) {
		cout << "go right";
		xI += 5;
		if (xI > 900)
			flag = true;
	}
	
	
	
}

bool flag5 = true;
void moveCar6() {                   // function to move player's taxi red
	
	if (i > 10 && flag5) {
		i -= 5;
		cout << "going left";
		if(i < 100)
			
			flag5 = false;

	}
	else if (i < 1010 && !flag5) {
		cout << "go right";
		i += 5;
		if (i > 900)
			flag5 = true;
	}
	
	
	
}


bool flag1 = true;
void moveCar2() {               // function to move bot car
	
	if (b > 10 && flag1) {
		b -= 5;
		cout << "going left";
		if(b < 400)
			
			flag1 = false;

	}
	else if (b < 800 && !flag1) {
		cout << "go right";
		b += 5;
		if (b > 550)
			flag1 = true;
	}
}




bool flag2 = true;
void moveCar3() {                 // function to move bot car
	
	if (c > 270 && flag2) {
		c -= 5;
		cout << "going left";
		if(c < 350)
			
			flag2 = false;

	}
	else if (c < 600 && !flag2) {
		cout << "go right";
		c += 5;
		if (c > 510 )
			flag2 = true;
	}
	
	}
	
	bool flag3 = true;
void moveCar4()          // function to move bot car
{
	
	if (f > 10 && flag3) {
		f -= 5;
		cout << "going left";
		if(f < 70)
			
			flag3 = false;

	}
	else if (f < 600 && !flag3) {
		cout << "go right";
		f += 5;
		if (f > 270 )
			flag3 = true;
	}
}



	bool flag4 = true;
void moveCar5()          // function to move bot car
{
	
	if (g > 10 && flag4) {
		g -= 5;
		cout << "going left";
		if(g < 720)
			
			flag4 = false;

	}
	else if (f < 600 && !flag4) {
		cout << "go right";
		g += 5;
		if (g > 900 )
			flag4 = true;
	}
}

void GameMenu (void)                                                                                                            // function for game menu displaying things
{
glClearColor(0,0,0, 10 ); // color decision
glClear (GL_COLOR_BUFFER_BIT); 


DrawRectangle( 50, 700 , 40,250 , colors[WHITE]);   // R
DrawSquare(50,850,150,colors [WHITE]);
DrawSquare(75,830,40,colors[WHITE]);
DrawSquare(110,790,40,colors[WHITE]);
DrawSquare( 145,760,40,colors[WHITE]);
DrawSquare(185,720,40,colors[WHITE]);
DrawSquare(88,880,80,colors[BLACK]);

DrawRectangle(234,730,40,270,colors[WHITE]);      // U
DrawRectangle(234,710,170,40,colors[WHITE]);
DrawRectangle(364,730,40,270,colors[WHITE]);


DrawRectangle(420,960,140,40,colors[WHITE]);      // S
DrawRectangle(420,860,40,120,colors[WHITE]);
DrawRectangle(420,830,140,40,colors[WHITE]);
DrawRectangle(520,730,40,140,colors[WHITE]);
DrawRectangle(420,710,140,40,colors[WHITE]);


DrawRectangle(575,710,40,285,colors[WHITE]);     // H
DrawRectangle(575,850,140,40,colors[WHITE]);
DrawRectangle(695,710,40,285,colors[WHITE]);


DrawRectangle(450,540,40,140,colors[WHITE]);     // H
DrawRectangle(450,590,110,40,colors[WHITE]);
DrawRectangle(550,540,40,140,colors[WHITE]);


DrawRectangle(600,540,100,140,colors[WHITE]);     // O
DrawRectangle(620,565,60,90,colors[BLACK]);


DrawRectangle(710,540,40,140,colors[WHITE]);      // U
DrawRectangle(710,540,80,40,colors[WHITE]);
DrawRectangle(780,540,40,140,colors[WHITE]);

DrawRectangle( 830, 540 , 40,140 , colors[WHITE]);   // R
DrawSquare(840,600,80,colors [WHITE]);
DrawSquare(860,575,30,colors[WHITE]);
DrawSquare(890,545,30,colors[WHITE]);
DrawSquare( 145,760,40,colors[WHITE]);
DrawSquare(185,720,40,colors[WHITE]);
DrawSquare(853,613,50,colors[BLACK]);




			DrawRectangle( 400, 360 , 150 , 40 , colors[WHITE] );
					DrawString( 440, 372, "START", colors[BLACK]);

			DrawRectangle( 390, 300 , 180 , 40 , colors[WHITE] );
		        DrawString( 405, 315, "LEADERBOARDS", colors[BLACK]);
glutSwapBuffers();

}

void Gameyellow(void)                                                                                                                   // function for game with yellow taxi
{

glClearColor(0.6,0.71,0.721, 10);
glClear (GL_COLOR_BUFFER_BIT); 
DrawString ( 20 , 1000 , "SCORE : " ,colors[BLACK]);
DrawString( 100, 1000,Num2Str(score) , colors[BLACK]);
	
	DrawRectangle( 45, 360 , 10 , 20 , colors[BROWN] );       // treeeeeeeeeeeeeeeesssss
	DrawCircle(50,390,15,colors[DARK_GREEN]);
	
	
	DrawRectangle( 105, 50 , 10 , 20 , colors[BROWN] );
	DrawCircle(110,80,15,colors[DARK_GREEN]);
			
			
	DrawRectangle( 770, 550 , 10 , 20 , colors[BROWN] );
	DrawCircle(775,580,15,colors[DARK_GREEN]);
	
	
	DrawRectangle( 480, 660 , 10 , 20 , colors[BROWN] );
	DrawCircle(485,690,15,colors[DARK_GREEN]);
	
	
	DrawRectangle( 830, 860 , 10 , 20 , colors[BROWN] );
	DrawCircle(835,890,15,colors[DARK_GREEN]);
	
	
	DrawRectangle( 100, 560 , 10 , 20 , colors[BROWN] );
	DrawCircle(105,590,15,colors[DARK_GREEN]);
	
	

if ((xI>40 && xI<=50) && (yI>=350 && yI <=400))            // for score deduction when taxi hits trees 
{
score =score -5;
}
if (( xI>=80 && xI<=120) && (yI>=40 && yI<=90 ))
{
score = score -5;
}
if (( xI>=740 && xI<=770) && (yI>=530 && yI<=590 ))
{
score = score -5;
}	
if (( xI>=460 && xI<=500) && (yI>=670 && yI<=700 ))
{
score = score -5;
}
if (( xI>=800 && xI<=850) && (yI>=840 && yI<=900 ))
{
score = score -5;
}
if (( xI>=60 && xI<=110) && (yI>=550 && yI<=620 ))
{
score = score -5;
}
 

	DrawLine( 30 , 50 ,  990 , 50 , 5, colors[BLACK] );	// grid outer most boundary
	DrawLine( 30 , 990 , 30  , 50 , 5, colors[BLACK] );
	DrawLine( 30 , 50 ,  600 , 50 , 5, colors[BLACK] );
	DrawLine( 990 , 990 ,  990 , 50 , 5, colors[BLACK] );
	DrawLine( 30 , 990 ,  990 , 990 , 5, colors[BLACK] );
	
	
	
	DrawLine( 90 , 990 ,  90 , 50 , 1, colors[BLACK] );
		DrawLine( 150 , 990 ,  150 , 50 , 1, colors[BLACK] );                     // inner grid lines
			DrawLine( 210 , 990 ,  210 , 50 , 1, colors[BLACK] );
				DrawLine( 270 , 990 ,  270 , 50 , 1, colors[BLACK] );
					DrawLine( 330 , 990 ,  330 , 50 , 1, colors[BLACK] );
						DrawLine( 390 , 990 ,  390 , 50 , 1, colors[BLACK] );
							DrawLine( 450 , 990 ,  450 , 50 , 1, colors[BLACK] );
								DrawLine( 510 , 990 ,  510 , 50 , 1, colors[BLACK] );
									DrawLine( 570 , 990 ,  570 , 50 , 1, colors[BLACK] );
										DrawLine( 630 , 990 ,  630 , 50 , 1, colors[BLACK] );
											DrawLine( 690 , 990 ,  690 , 50 , 1, colors[BLACK] );
												DrawLine( 750 , 990 ,  750 , 50 , 1, colors[BLACK] );
													DrawLine( 810 , 990 ,  810 , 50 , 1, colors[BLACK] );
														DrawLine( 870 , 990 ,  870 , 50 , 1, colors[BLACK] );
															DrawLine( 930 , 990 ,  930 , 50 , 1, colors[BLACK] );
																DrawLine( 990 , 990 ,  990 , 50 , 1, colors[BLACK] );
																
																
		DrawRectangle( 30 , 300 , 480  , 60, colors[TAN] );            // buildings codes
		DrawRectangle( 450 , 350 , 60  , 100, colors[TAN] );
		DrawRectangle( 590 , 800 , 400  , 60, colors[	BLACKO] );         
		DrawRectangle( 690 , 750 , 60  , 140, colors[BLACKO] );
		DrawRectangle( 270, 600 , 60 , 390 , colors[BROWN] );
		
		DrawRectangle( 590 , 200 , 400  , 60, colors[SADDLE_BROWN] );
		DrawRectangle( 570 , 160 , 60  , 130, colors[SADDLE_BROWN] );
		
		
		DrawRectangle( 750 , 200 , 60  , 350, colors[SADDLE_BROWN] );
		DrawRectangle( 400 , 600 , 300  , 60, colors[GOLD] );
		
		DrawRectangle( 270, 200 , 60 , 140 , colors[TAN] );
		
		DrawRectangle( 30, 500 , 140 , 60 , colors[PERU] );
		
		
		DrawRectangle( 700, 10 , 150 , 30 , colors[BLACK] );
	DrawString( 708, 16, "LEADERBOARD", colors[WHITE]);



drawCaryellow();    // function call for yellow taxi


	drawCar3();  // bot cars funstion calls
	drawCar2();
	drawCar4();
	drawCar5();
	glutSwapBuffers(); 
	
	             // below is the code to restrict car into boundary 
	
if ((xI>=30 && xI<=990) && (yI>=970))
{ yI=yI-10;
}	
if ((xI>=30 && xI<=40) && (yI>=50 && yI<=970))
{ xI=xI+10;
}	
if ((xI>=930 && xI<=950) && (yI>=50 && yI<=970))
{ xI=xI-10;
}
if ((xI>=30 && xI<=990) && (yI>=50 && yI<=60))
{ yI=yI+10;
}	
	
	
	
	
if ((xI>=210 && xI<=330) && (yI>=700 && yI<=990))
{
xI=xI-10;
}
	
if ((xI>=260 && xI<=330) && (yI>=600 && yI<=990))
{ xI=xI+7;
}
if ((xI>=40 && xI<=170) && (yI>=480 && yI<=530))
{
yI=yI-10;
}

if ((xI>=40 && xI<=170) && (yI>=545 && yI<=570))
{
yI=yI+10;
}

if ((xI>=30 && xI<=510) && (yI<=370 && yI>=330))
{
yI=yI+7;
}
if ((xI>=40 && xI<=510) && (yI>=275 && yI<=300))
{
yI=yI-7;
}

if ((xI>=390 && xI<=460) && (yI>=300 && yI<=450))
{
xI=xI-10;
}

if ((xI>=370 && xI<=700) && (yI>=580 && yI<=630))
{
yI=yI-10;
}
if ((xI>=370 && xI<=700) && (yI>=630 && yI<=660))
{
yI=yI+10;
}
if ((xI>=700 && xI<=800) && (yI>=230 && yI<=550))
{
xI=xI-10;
}
if ((xI>=750 && xI<=810) && (yI>=230 && yI<=550))
{
xI=xI+10;
}
if ((xI>=600 && xI<=990) && (yI>=220 && yI<=260))
{
yI=yI+10;
}
if ((xI>=530 && xI<=990) && (yI>=780 && yI<=850))
{
yI=yI-10;
}
if ((xI>=530 && xI<=990) && (yI>=810 && yI<=870))
{
yI=yI+10;
}






}

void Gamered(void)                                                                                                                   // function for game when taxi is red
{

glClearColor(0.6,0.71,0.721, 10); // color decision
glClear (GL_COLOR_BUFFER_BIT); 

DrawString ( 20 , 1000 , "SCORE : " ,colors[BLACK]);
DrawString( 100, 1000,Num2Str(score) , colors[BLACK]);
	
	DrawRectangle( 45, 360 , 10 , 20 , colors[BROWN] ); // treeeeeeeeeeeeeeeeeeeeeeeeees
	DrawCircle(50,390,15,colors[DARK_GREEN]);
	
	
	DrawRectangle( 105, 50 , 10 , 20 , colors[BROWN] );
	DrawCircle(110,80,15,colors[DARK_GREEN]);
			
			
	DrawRectangle( 770, 550 , 10 , 20 , colors[BROWN] );
	DrawCircle(775,580,15,colors[DARK_GREEN]);
	
	
	DrawRectangle( 480, 660 , 10 , 20 , colors[BROWN] );
	DrawCircle(485,690,15,colors[DARK_GREEN]);
	
	
	DrawRectangle( 830, 860 , 10 , 20 , colors[BROWN] );
	DrawCircle(835,890,15,colors[DARK_GREEN]);
	
	
	DrawRectangle( 100, 560 , 10 , 20 , colors[BROWN] );
	DrawCircle(105,590,15,colors[DARK_GREEN]);
	
	
if ((i>40 && i<=50) && (j>=350 && j <=400))
{
score =score -5;
}
if (( i>=80 && i<=120) && (j>=40 && j<=90 ))     // score deduction when taxi runs over trees
{
score = score -5;
}
if (( i>=740 && i<=770) && (j>=530 && j<=590 ))
{
score = score -5;
}	
if (( i>=460 && i<=500) && (j>=670 && j<=700 ))
{
score = score -5;
}
if (( i>=800 && i<=850) && (j>=840 && j<=900 ))
{
score = score -5;
}
if (( i>=60 && i<=110) && (j>=550 && j<=620 ))
{
score = score -5;
}
	
	

 

	DrawLine( 30 , 50 ,  990 , 50 , 5, colors[BLACK] );	
	DrawLine( 30 , 990 , 30  , 50 , 5, colors[BLACK] );         // outer most boundary
	DrawLine( 30 , 50 ,  600 , 50 , 5, colors[BLACK] );
	DrawLine( 990 , 990 ,  990 , 50 , 5, colors[BLACK] );
	DrawLine( 30 , 990 ,  990 , 990 , 5, colors[BLACK] );
	
	
	
	DrawLine( 90 , 990 ,  90 , 50 , 1, colors[BLACK] );                           // inner grid lines
		DrawLine( 150 , 990 ,  150 , 50 , 1, colors[BLACK] );
			DrawLine( 210 , 990 ,  210 , 50 , 1, colors[BLACK] );
				DrawLine( 270 , 990 ,  270 , 50 , 1, colors[BLACK] );
					DrawLine( 330 , 990 ,  330 , 50 , 1, colors[BLACK] );
						DrawLine( 390 , 990 ,  390 , 50 , 1, colors[BLACK] );
							DrawLine( 450 , 990 ,  450 , 50 , 1, colors[BLACK] );
								DrawLine( 510 , 990 ,  510 , 50 , 1, colors[BLACK] );
									DrawLine( 570 , 990 ,  570 , 50 , 1, colors[BLACK] );
										DrawLine( 630 , 990 ,  630 , 50 , 1, colors[BLACK] );
											DrawLine( 690 , 990 ,  690 , 50 , 1, colors[BLACK] );
												DrawLine( 750 , 990 ,  750 , 50 , 1, colors[BLACK] );
													DrawLine( 810 , 990 ,  810 , 50 , 1, colors[BLACK] );
														DrawLine( 870 , 990 ,  870 , 50 , 1, colors[BLACK] );
															DrawLine( 930 , 990 ,  930 , 50 , 1, colors[BLACK] );
																DrawLine( 990 , 990 ,  990 , 50 , 1, colors[BLACK] );
																
																
		DrawRectangle( 30 , 300 , 480  , 60, colors[TAN] );
		DrawRectangle( 450 , 350 , 60  , 100, colors[TAN] );             // building codes
		DrawRectangle( 590 , 800 , 400  , 60, colors[	BLACKO] );
		DrawRectangle( 690 , 750 , 60  , 140, colors[BLACKO] );
		DrawRectangle( 270, 600 , 60 , 390 , colors[BROWN] );
		
		DrawRectangle( 590 , 200 , 400  , 60, colors[SADDLE_BROWN] );
		DrawRectangle( 570 , 160 , 60  , 130, colors[SADDLE_BROWN] );
		
		
		DrawRectangle( 750 , 200 , 60  , 350, colors[SADDLE_BROWN] );
		DrawRectangle( 400 , 600 , 300  , 60, colors[GOLD] );
		
		DrawRectangle( 270, 200 , 60 , 140 , colors[TAN] );
		
		DrawRectangle( 30, 500 , 140 , 60 , colors[PERU] );
		
		
		DrawRectangle( 700, 10 , 150 , 30 , colors[BLACK] );
	DrawString( 708, 16, "LEADERBOARD", colors[WHITE]);



drawCarred();             // function call for red raxi


	drawCar3();    // bot cars function calls
	drawCar2();
	drawCar4();
	drawCar5();
	glutSwapBuffers(); 
	
	             // below is the code to restrict car into boundary 
	
	if ((i>=30 && i<=990) && (j>=970))
{ j=j-10;
}	
if ((i>=30 && i<=40) && (j>=50 && j<=970))
{ i=i+10;
}	
if ((i>=930 && i<=950) && (j>=50 && j<=970))
{ i=i-10;
}
if ((i>=30 && i<=990) && (j>=50 && j<=60))
{ j=j+10;
}
	
if ((i>=210 && i<=330) && (j>=700 && j<=990))
{
i=i-10;
}
	
if ((i>=260 && i<=330) && (j>=600 && j<=990))
{ 
i=i+7;
}
if ((i>=40 && i<=170) && (j>=480 && j<=530))
{
j=j-10;
}

if ((i>=30 && i<=510) && (j<=370 && j>=330))
{
j=j+7;
}
if ((i>=40 && i<=510) && (j>=275 && j<=300))
{
j=j-7;
}

if ((i>=390 && i<=460) && (j>=300 && j<=450))
{
i=i-10;
}

if ((i>=370 && i<=700) && (j>=580 && j<=630))
{
j=j-10;
}
if ((i>=370 && i<=700) && (j>=630 && j<=660))
{
j=j+10;
}
if ((i>=700 && i<=800) && (j>=230 && j<=550))
{
i=i-10;
}
if ((i>=750 && i<=810) && (j>=230 && j<=550))
{
i=i+10;
}
if ((i>=600 && i<=990) && (j>=220 && j<=260))
{
j=j+10;
}
if ((i>=530 && i<=990) && (j>=780 && j<=850))
{
j=j-10;
}
if ((i>=530 && i<=990) && (j>=810 && j<=870))
{
j=j+10;
}

	







}






void leaderboard (void)                                                                                                            // function for leaderboard display
{
glClearColor(0.21,0.21,0.21, 10 );
glClear (GL_COLOR_BUFFER_BIT); 

DrawSquare( 100, 100 , 750, colors[BLACK]);
                       				DrawRectangle ( 300,900,300,60,colors[BLACK]);
                       					DrawString( 375, 920, "LEADERBOARDS", colors[MISTY_ROSE]);
			
					DrawString( 105, 800, "SCORES:", colors[WHITE]);
                                       DrawString( 110, 750, "Abdullah : 192", colors[WHITE]);
                                     	DrawString( 110, 730, "Noman : 153", colors[WHITE]);
                                     	DrawString( 110, 710, "Saud Naseer : 102", colors[WHITE]);
                       DrawRectangle( 480, 50, 200,40,colors[BLACK]);
                   	DrawString( 490, 60, "PRESS S TO START", colors[WHITE]);              	
                                     	
			
glutSwapBuffers();

}





void color (void)                                                                                                            // function for taxi color decision
{
glClearColor(0.3,0.1,0.3, 10 );
glClear (GL_COLOR_BUFFER_BIT); 


                       DrawRectangle( 170, 300, 250,50,colors[GOLD]);
                   	DrawString( 175, 320, "PRESS Y for YELLOW TAXI", colors[BLACK]);  
                   	
DrawRectangle( 250, 260+3 , 40 , 20 , colors[BLACK] );	
DrawRectangle( 250-4, 260-5 , 63 , 20 , colors[GOLD] );
DrawSquare(250+1,260-10,15,colors[BLACK]);
DrawSquare(250+33,260-10,15,colors[BLACK]);
DrawSquare(250+53,260+2,6,colors[BLUE]);

	glutPostRedisplay();
	
	DrawRectangle( 500, 300, 250,50,colors[BROWN]);
                   	DrawString( 505, 320, "PRESS R for RED TAXI", colors[BLACK]);  
                   	
DrawRectangle( 580, 260+3 , 40 , 20 , colors[BLACK] );	
DrawRectangle( 580-4, 260-5 , 63 , 20 , colors[BROWN] );
DrawSquare(580+1,260-10,15,colors[BLACK]);
DrawSquare(580+33,260-10,15,colors[BLACK]);
DrawSquare(580+53,260+2,6,colors[BLUE]);

	glutPostRedisplay();
                   	
                   	
                   	DrawRectangle( 50, 700 , 40,250 , colors[WHITE]);   // R
DrawSquare(50,850,150,colors [WHITE]);
DrawSquare(75,830,40,colors[WHITE]);
DrawSquare(110,790,40,colors[WHITE]);
DrawSquare( 145,760,40,colors[WHITE]);
DrawSquare(185,720,40,colors[WHITE]);
DrawSquare(88,880,80,colors[BLACK]);

DrawRectangle(234,730,40,270,colors[WHITE]);      // U
DrawRectangle(234,710,170,40,colors[WHITE]);
DrawRectangle(364,730,40,270,colors[WHITE]);


DrawRectangle(420,960,140,40,colors[WHITE]);      // S
DrawRectangle(420,860,40,120,colors[WHITE]);
DrawRectangle(420,830,140,40,colors[WHITE]);
DrawRectangle(520,730,40,140,colors[WHITE]);
DrawRectangle(420,710,140,40,colors[WHITE]);


DrawRectangle(575,710,40,285,colors[WHITE]);     // H
DrawRectangle(575,850,140,40,colors[WHITE]);
DrawRectangle(695,710,40,285,colors[WHITE]);


DrawRectangle(450,540,40,140,colors[WHITE]);     // H
DrawRectangle(450,590,110,40,colors[WHITE]);
DrawRectangle(550,540,40,140,colors[WHITE]);


DrawRectangle(600,540,100,140,colors[WHITE]);     // O
DrawRectangle(620,565,60,90,colors[BLACK]);


DrawRectangle(710,540,40,140,colors[WHITE]);      // U
DrawRectangle(710,540,80,40,colors[WHITE]);
DrawRectangle(780,540,40,140,colors[WHITE]);

DrawRectangle( 830, 540 , 40,140 , colors[WHITE]);   // R
DrawSquare(840,600,80,colors [WHITE]);
DrawSquare(860,575,30,colors[WHITE]);
DrawSquare(890,545,30,colors[WHITE]);
DrawSquare( 145,760,40,colors[WHITE]);
DrawSquare(185,720,40,colors[WHITE]);
DrawSquare(853,613,50,colors[BLACK]);

                   	
                   	            	
                                     	
			
glutSwapBuffers();

}



/*
 * Main Canvas drawing function.
 * */
int menuflag = 1;
bool MENU = true;
void GameDisplay()                       // main display function
{
	if (menuflag == 1)
	{ 
	       GameMenu();
	}
	else if (menuflag==2)
	{
		color();
	}
	else if (menuflag==3)
	{
	      leaderboard();
	}
else if (menuflag==4) 
	{
	 Gameyellow();
	}
	else if (menuflag==5)
	{
	Gamered();
	}
}


/*This function is called (automatically) whenever any non-printable key (such as up-arrow, down-arraw)
 * is pressed from the keyboard
 *
 * You will have to add the necessary code here when the arrow keys are pressed or any other key is pressed...
 *
 * This function has three argument variable key contains the ASCII of the key pressed, while x and y tells the
 * program coordinates of mouse pointer when key was pressed.
 *
 * */

void NonPrintableKeys(int key, int x, int y) {                                            // this function defines the speed of both taxis
	if (key == GLUT_KEY_LEFT ) {
		
		 
                i -=5;
                xI -=10;
	} 		
	else if (key == GLUT_KEY_RIGHT ) {
		xI += 10;
		i +=5;
	} else if (key
			== GLUT_KEY_UP/*GLUT_KEY_UP is constant and contains ASCII for up arrow key*/) {
		yI += 10;
		j +=5;
	}

	else if (key
			== GLUT_KEY_DOWN/*GLUT_KEY_DOWN is constant and contains ASCII for down arrow key*/) {
		yI -= 10;
		j -= 5;
	}

	/* This function calls the Display function to redo the drawing. Whenever you need to redraw just call
	 * this function*/

	glutPostRedisplay();

}

/*This function is called (automatically) whenever any printable key (such as x,b, enter, etc.)
 * is pressed from the keyboard
 * This function has three argument variable key contains the ASCII of the key pressed, while x and y tells the
 * program coordinates of mouse pointer when key was pressed.
 * */
void PrintableKeys(unsigned char key, int x, int y) {                                // this function assigns values to the integer depending upon what key is pressed.
	if (key == 27/* Escape key ASCII*/) {
		exit(1); // exit the program when escape key is pressed.
	}

	if (key == 's' || key == 'S') //Key for placing the bomb
			{
		menuflag=2;
		cout << "s pressed" << endl;

	               }
	if ( key == 'l' || key == 'L' )
	{
	menuflag=3;
	cout<<"l pressed"<<endl;
	}
	if (key == 'y' || key =='Y' )
	{
	menuflag=4;
	}
	if(key == 'r' || key == 'R' )
	{
	menuflag=5;
	cout<<"r pressed"<<endl;
	}
	
	

	glutPostRedisplay();
}



/*
 * This function is called after every 1000.0/FPS milliseconds
 * (FPS is defined on in the beginning).
 * You can use this function to animate objects and control the
 * speed of different moving objects by varying the constant FPS.
 *
 * */
void Timer(int m) {                                     // timer function to control bot cars movement

	
moveCar2();
moveCar3();
moveCar4();
moveCar5();
	// once again we tell the library to call our Timer function after next 1000/FPS
	glutTimerFunc(100, Timer, 3);
}

/*This function is called (automatically) whenever your mouse moves witin inside the game window
 *
 * You will have to add the necessary code here for finding the direction of shooting
 *
 * This function has two arguments: x & y that tells the coordinate of current position of move mouse
 *
 * */
void MousePressedAndMoved(int x, int y) {
	cout << x << " " << y << endl;
	glutPostRedisplay();
}
void MouseMoved(int x, int y) {
	//cout << x << " " << y << endl;
	glutPostRedisplay();
}

/*This function is called (automatically) whenever your mouse button is clicked witin inside the game window
 *
 * You will have to add the necessary code here for shooting, etc.
 *
 * This function has four arguments: button (Left, Middle or Right), state (button is pressed or released),
 * x & y that tells the coordinate of current position of move mouse
 *
 * */
void MouseClicked(int button, int state, int x, int y) {

	if (button == GLUT_LEFT_BUTTON) // dealing only with left button
			{
		cout << GLUT_DOWN << " " << GLUT_UP << endl;

	} else if (button == GLUT_RIGHT_BUTTON) // dealing with right button
			{
			cout<<"Right Button Pressed"<<endl;

	}
	glutPostRedisplay();
}
/*
 * our gateway main function
 * */
int main(int argc, char*argv[]) {

	int width = 1024, height = 1024; // i have set my window size to be 800 x 600

	InitRandomizer(); // seed the random number generator...
	glutInit(&argc, argv); // initialize the graphics library...
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA); // we will be using color display mode
	glutInitWindowPosition(50, 50); // set the initial position of our window
	glutInitWindowSize(width, height); // set the size of our window
	glutCreateWindow("RUSH HOUR || Abdullah Khan"); // set the title of our game window
	SetCanvasSize(width, height); // set the number of pixels...

	// Register your functions to the library,
	// you are telling the library names of function to call for different tasks.
	//glutDisplayFunc(display); // tell library which function to call for drawing Canvas.

	glutDisplayFunc(GameDisplay); // tell library which function to call for drawing Canvas.
	glutSpecialFunc(NonPrintableKeys); // tell library which function to call for non-printable ASCII characters
	glutKeyboardFunc(PrintableKeys); // tell library which function to call for printable ASCII characters
	// This function tells the library to call our Timer function after 1000.0/FPS milliseconds...
	glutTimerFunc(1000.0, Timer, 0);

	glutMouseFunc(MouseClicked);
	glutPassiveMotionFunc(MouseMoved); // Mouse
	glutMotionFunc(MousePressedAndMoved); // Mouse

	// now handle the control to library and it will call our registered functions when
	// it deems necessary...
	glutMainLoop();
	return 1;
}
#endif /* RushHour_CPP_ */

#ifndef HANGMAN_H
#define HANGMAN_H

void playHangMan();

#endif
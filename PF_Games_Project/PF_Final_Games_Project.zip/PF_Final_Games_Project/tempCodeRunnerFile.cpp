cd /mnt/c/Coding_Files/PF_Games_Project/
g++ menu.cpp hang_man_HK-NM.cpp tic_tac_toe_AJ.cpp number_guessing_ZH.cpp rock_scissor_RN.cpp pac_man_JZ-AJ.cpp  -o menu
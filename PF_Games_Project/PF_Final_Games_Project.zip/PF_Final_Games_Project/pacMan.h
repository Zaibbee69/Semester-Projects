#ifndef PACMAN_H
#define PACMAN_H

void playPacMan();

#endif
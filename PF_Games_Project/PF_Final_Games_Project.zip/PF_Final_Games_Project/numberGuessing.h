#ifndef NUMBERGUESSING_H
#define NUMBERGUESSING_H

void playNumberGuessing();

#endif
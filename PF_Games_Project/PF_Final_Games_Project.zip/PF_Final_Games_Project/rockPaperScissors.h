#ifndef ROCKPAPERSCISSORS_H
#define ROCKPAPERSCISSORS_H

void playRockPaperScissors();

#endif // ROCKPAPERSCISSORS_H

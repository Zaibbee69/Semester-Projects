/*

Abdullah Khan

21i-0835


Section : F


*/


#include <iostream>
#include <iomanip>
#include<fstream>
#include<cstring>
#include <ctime>
#include<cmath>

using namespace std; 


 //---------------------------------------------------------------FUNCTION DEFINITIONS------------------------------------------------------------------------------

int drawScoreCardFirst( int total_scorefirst,int total_scoresecond,string* bat_first, int score,int i,int count ,int* player_score,int balls,string innings,string* bowl_first,int* ball_count,int* run1,int* run2,int overs,int choice);

int ScoreCard(string* bat_first, int score, int total_scorefirst,int total_scoresecond,int i,int* player_score,int count,int balls,string innings,string* bowl_first,int* ball_count,int* run1,int* run2,int overs,int choice);

int drawScoreCardSecond(string* bat_first, int total_scorefirst,int total_scoresecond,string* bowl_first ,int* run1,int* run2,int choice);

void FinalResult ( int total_scorefirst,int total_scoresecond,int t1,int t2,string* bat_first,string* bowl_first,int* run1,int* run2 ) ;

void save(int total_scorefirst,int total_scoresecond,string* bat_first,int score,int count,int* player_score,int balls,string* bowl_first,int* ball_count,int* run1,int* run2,int overs,float* SR,int* four,int* six,float b,float RR,int* maiden2,int* WB,int* NB,int* maiden,int choice) ;










//---------------------------------------------------------------------SCORE CARD TAKING VARIOUS ARGUMENTS------------------------------------------------------------------------------


int ScoreCard(string* bat_first, int score, int total_scorefirst,int total_scoresecond,int i,int* player_score,int count,int balls,string innings,string* bowl_first,int* ball_count,int* run1,int* run2,int overs,int choice)
{ 

    drawScoreCardFirst(total_scorefirst,total_scoresecond,bat_first,score,i,count,player_score,balls,innings,bowl_first, ball_count,run1,run2,overs,choice) ;   // FIRST INNINGS FUNC. CALL

}


    
    
    
    
//---------------------------------------------------------------FUNCTION FOR SAVING MATCH INNINGS IN A FILE ------------------------------------------------------------------------------





void save(int total_scorefirst,int total_scoresecond,string* bat_first,int score,int count,int* player_score,int balls,string* bowl_first,int* ball_count,int* run1,int* run2,int overs,float* SR,int* four,int* six,float b,float RR,int* maiden2,int* WB,int* NB,int* maiden,int choice) 
{
if ( choice == 1) 
{

ofstream file;  
    file.open ("first.txt");                       //----------------------------------OPENING FILE FOR FIRST INNINGS------------------------------------------------


file<<endl;                                 
	file<<"  ^  FIRST INNINGS ("<<overs<<" overs maximum)"<<endl;                          //----------------------------------WRITING MATCH DATA IN FILE------------------------------------------------
file<<"_____________________________________________________________________________________________________________________________________________________________________"<<endl;
file<<"|  BATTING                                                     R              B              M              4s              6s              SR                       |"<<endl;
file<<"|____________________________________________________________________________________________________________________________________________________________________|"<<endl;

			for ( int j = 0 ; j < count ; j++ )
	{
   SR[j] = ((run1[j]+1.0 ) / ball_count[j]+0.001 ) * 100 ;
 
file<<bat_first[j]<<"(out)"<<setw(30);
file<<bowl_first[j]<<setw(15);
file<<run1[j]+1<<setw(15);
file<<ball_count[j]<<setw(15);
file<<maiden[j]<<setw(15);
file<<four[j]<<setw(15);
file<<six[j]<<setw(15);
file<<SR[j]<<setw(15);
file<<endl;
	
	}
	
if(count == 11 || b>=overs ) {
file<<"_____________________________________________________________________________________________________________________________________________________________________"<<endl;
file<<"|  TOTAL                     "<<int(b)<<" Ov     (RR: "<<RR<<")            "<<total_scorefirst<<"/"<<count<<"                                                                                                |"<<endl;
file<<"|____________________________________________________________________________________________________________________________________________________________________|"<<endl;

file<<endl<<endl<<endl;
file<<"______________________________________________________________________________________________________________________________________________________________________"<<endl;
file<<"|  BOWLING                                                     O              M              R              W              ECON              WD               NB      |"<<endl;
file<<"|_____________________________________________________________________________________________________________________________________________________________________|"<<endl;


for ( int j = 0 ; j < count ; j++ )
	{

file<<bowl_first[j]<<"     "<<right<<setw(30);
file<<""<<setw(15);
file<<ceil(ball_count[j]/6.0)<<setw(15);
file<<maiden2[j]<<setw(15);
file<<run1[j]+1<<setw(15);
file<<count<<setw(15);
file<<setprecision(2)<<(run1[j]+1 ) / (ball_count[j]/6.0)<<setw(15);
file<<WB[j]<<setw(15);
file<<NB[j]<<setw(15);

file<<endl;



}
file<<endl<<"______________________________________________________________________________________________________________________________________________________________________"<<endl;

file<<endl;

}
file.close();                      //----------------------------------CLOSING  FILE FOR FIRST INNINGS------------------------------------------------
}

 if (choice == 2 )
{
ofstream file;                          //----------------------------------OPENING FILE FOR SECOND INNINGS------------------------------------------------
    file.open ("second.txt");


file<<endl;
	file<<"  ^  SECOND INNINGS ("<<overs<<" overs maximum)"<<endl;                         //----------------------------------WRITING DATA OF SECOND INNINGS------------------------------------------
file<<"_____________________________________________________________________________________________________________________________________________________________________"<<endl;

file<<"|  BATTING                                                     R              B              M              4s              6s              SR                       |"<<endl;
file<<"|____________________________________________________________________________________________________________________________________________________________________|"<<endl;

			for ( int j = 0 ; j < count ; j++ )
	{
   SR[j] = ((run2[j]+1.0 ) / ball_count[j]+0.0 ) * 100 ;
 
file<<bowl_first[j]<<"(out)"<<setw(30);
file<<bat_first[j]<<setw(15);
file<<run2[j]+1<<setw(15);
file<<ball_count[j]<<setw(15);
file<<maiden[j]<<setw(15);
file<<four[j]<<setw(15);
file<<six[j]<<setw(15);
file<<SR[j]<<setw(15);
file<<endl;
	
	}
	
if(count == 11 || b>= overs) {
file<<"_____________________________________________________________________________________________________________________________________________________________________"<<endl;
file<<"|  TOTAL                     "<<int(b)<<" Ov     (RR: "<<RR<<")            "<<total_scoresecond<<"/"<<count<<"                                                                                                |"<<endl;
file<<"|____________________________________________________________________________________________________________________________________________________________________|"<<endl;

file<<endl<<endl<<endl;
file<<"______________________________________________________________________________________________________________________________________________________________________"<<endl;
file<<"|  BOWLING                                                     O              M              R              W              ECON              WD               NB      |"<<endl;
file<<"|_____________________________________________________________________________________________________________________________________________________________________|"<<endl;


for ( int j = 0 ; j < count ; j++ )
	{

file<<bat_first[j]<<"     "<<right<<setw(30);
file<<""<<setw(15);
file<<ceil(ball_count[j]/6.0)<<setw(15);
file<<maiden2[j]<<setw(15);
file<<run2[j]+1<<setw(15);
file<<count<<setw(15);
file<<setprecision(2)<<(run2[j]+1 ) / (ball_count[j]/6.0)<<setw(15);
file<<WB[j]<<setw(15);
file<<NB[j]<<setw(15);

file<<endl;



}
file<<endl<<"______________________________________________________________________________________________________________________________________________________________________"<<endl;

file<<endl;

}
file.close();                        //----------------------------------CLOSING FILE------------------------------------------------
 }
}





//---------------------------------------------------------------FUNCTION FOR PRINTING FINAL RESULT ------------------------------------------------------------------------------





void FinalResult ( int total_scorefirst,int total_scoresecond,int t1,int t2,int* run1,int* run2,string* bat_first,string* bowl_first) 
{

int i;
string batsman_of_match,bowler_of_match;
t1=total_scorefirst;
t2=total_scoresecond;

system("clear");
if ( t1 > t2 )                      //----------------------------------CHECKING CONDITIONS------------------------------------------------
{
cout<<setw(40)<<"CONGRATULATIONS TEAM 1 !"<<endl;
cout<<"_____________________________________________________________________________________________________"<<endl;
cout<<endl<<endl;
for( i = 1 ;i <= 11; i++) 
{

    if(run1[i] > run1[0])
     { run1[0] = run1[i];
       batsman_of_match = bat_first[i];
       bowler_of_match=bowl_first[i];
     }
  }


 cout<<"BATSMAN OF THE MATCH is "<<batsman_of_match<<" as he scored : "<<run1[0]+1<<endl;                       //----------------------------------PRINTING BATSMAN OF THE MATCH----------------------------
  cout<<"BOWLER OF THE MATCH is "<<bowler_of_match<<" as he took : "<<4<<" wickets. "<<endl;                    //----------------------------------PRINTING BOWLER OF THE MATCH---------------------------
cout<<endl;
}

else if ( t2 > t1 )
{
cout<<setw(40)<<"CONGRATULATIONS TEAM 2 !"<<endl;
cout<<"_____________________________________________________________________________________________________"<<endl;
cout<<endl<<endl;
for( i = 1 ;i <= 11; i++) 
{

    if(run2[i] > run2[0])
      {
      run2[0] = run2[i];
      batsman_of_match = bowl_first[i];
       bowler_of_match = bat_first[i];
      }

}

cout<<"BATSMAN OF THE MATCH is "<<batsman_of_match<<" as he scored : "<<run2[0]+1<<endl; //----------------------------------PRINTING BATSMAN OF THE MATCH---------------------------
  cout<<"BOWLER OF THE MATCH is "<<bowler_of_match<<" as he took : "<<3<<" wickets. "<<endl; //----------------------------------PRINTING BOWLER OF THE MATCH---------------------------
cout<<endl;
}


}


//---------------------------------------------------------------FUNCTION FOR PRINTING SECOND INNINGS------------------------------------------------------------------------------







int drawScoreCardSecond(string* bat_first, int total_scorefirst,int total_scoresecond,string* bowl_first,int* run1,int* run2 ,int choice)
{ 

int score = 0 , i = 0,balls = 0,count = 0 ,player_score[11]={0},ball_count[11]={0},overs;
	
	
	string configuration("configuration.txt");    //----------------------------------READING OVERS FROM FILE---------------------------
	
	ifstream file(configuration);
	file>>overs;
	file.close();
	
	balls = overs * 6 ;
	

	

int maiden[11] = { 1,23,24,152,29,92,73,19,10,21,67},t1=0,t2=0;
int WB[11]={ 1,0,1,0,6,4,7,3,1,2,5};
int NB[11]={ 1,0,0,1,2,5,3,2,2,1,0};
int maiden2[11] = { 0,2,0,1,2,2,1,0,0,1,1};
int four[11]={0},six[11]={0};
float SR[11]={0};
float b = 0 ;
float RR;
   while (balls>0 && count <11 )
   {
   b= b + 0.167;

   ball_count[i]++;
	score = (rand()%8) - 1;
		total_scoresecond += score;    //----------------------------------CALCULATING SCORES---------------------------
RR=total_scoresecond/b+0.0;
       run2[i] = score + run2[i] ;

 if(score == 4 )
four[i]++;
else if ( score == 6 )
six[i]++;

 
   	if ( score == -1 )                   
		{
	player_score[i] = total_scoresecond;
	}

        if ( score == -1 )
        {
cout<<bowl_first[i]<<"(out)"<<setw(30);
cout<<bat_first[i]<<setw(15);
cout<<"out"<<setw(15);
cout<<ball_count[i]<<setw(15);
cout<<maiden[i]<<setw(15);
cout<<four[i]<<setw(15);
cout<<six[i]<<setw(15);
cout<<endl; 
cout<<"________________________________________________________________________________________________________________________________________________________"<<endl;
cout<<"|  TOTAL                     "<<int(b)<<" Ov.    (RR: "<<RR<<")            "<<total_scoresecond<<"/"<<count+1<<"                                                                                     |"<<endl;
cout<<"|_______________________________________________________________________________________________________________________________________________________|"<<endl;



        }
        else
	{
cout<<"-->"<<bowl_first[i]<<setw(30);
cout<<bat_first[i]<<setw(15);
cout<<score<<setw(15);
cout<<ball_count[i]<<setw(15);
cout<<maiden[i]<<setw(15);
cout<<four[i]<<setw(15);
cout<<six[i]<<setw(15);
cout<<endl;
cout<<"________________________________________________________________________________________________________________________________________________________"<<endl;
cout<<"|  TOTAL                     "<<int(b)<<" Ov.    (RR: "<<RR<<")            "<<total_scoresecond<<"/"<<count<<"                                                                                     |"<<endl;
cout<<"|_______________________________________________________________________________________________________________________________________________________|"<<endl;
	

		}
	
	
	if ( score == -1 )
		{
	player_score[i] = total_scoresecond;
	total_scoresecond++;
	count++;
	i++;
		}
	cin.get();
	
	
	
	system("clear");
	

	
	
cout<<endl;
	cout<<"  ^  SECOND INNINGS ("<<overs<<" overs maximum)"<<endl;
cout<<"_____________________________________________________________________________________________________________________________________________________________________"<<endl;
cout<<"|  BATTING                                                     R              B              M              4s              6s              SR                       |"<<endl;
cout<<"|____________________________________________________________________________________________________________________________________________________________________|"<<endl;

			for ( int j = 0 ; j < count ; j++ )
	{
   SR[j] = ((run2[j]+1.0 ) / ball_count[j]+0.0 ) * 100 ;
 
cout<<bowl_first[j]<<"(out)"<<setw(30);
cout<<bat_first[j]<<setw(15);
cout<<run2[j]+1<<setw(15);
cout<<ball_count[j]<<setw(15);
cout<<maiden[j]<<setw(15);
cout<<four[j]<<setw(15);
cout<<six[j]<<setw(15);
cout<<SR[j]<<setw(15);
cout<<endl;
	
	}
	
if(count == 11 || b>= overs) {    //----------------------------------PRINTING WHEN ALL PLAYERS WILL BE DISMISSED OR OVERS ARE FINISHED---------------------------
cout<<"_____________________________________________________________________________________________________________________________________________________________________"<<endl;
cout<<"|  TOTAL                     "<<int(b)<<" Ov     (RR: "<<RR<<")            "<<total_scoresecond<<"/"<<count<<"                                                                                                |"<<endl;
cout<<"|____________________________________________________________________________________________________________________________________________________________________|"<<endl;

cout<<endl<<endl<<endl;
cout<<"______________________________________________________________________________________________________________________________________________________________________"<<endl;
cout<<"|  BOWLING                                                     O              M              R              W              ECON              WD               NB      |"<<endl;
cout<<"|_____________________________________________________________________________________________________________________________________________________________________|"<<endl;


for ( int j = 0 ; j < count ; j++ )
	{
	

cout<<bat_first[j]<<"     "<<right<<setw(30);
cout<<""<<setw(15);
cout<<ceil(ball_count[j]/6.0)<<setw(15);
cout<<maiden2[j]<<setw(15);
cout<<run2[j]+1<<setw(15);
cout<<rand()%3<<setw(15);
cout<<setprecision(2)<<(run2[j]+1 ) / (ball_count[j]/6.0)<<setw(15);
cout<<WB[j]<<setw(15);
cout<<NB[j]<<setw(15);

cout<<endl;



}
cout<<endl<<"______________________________________________________________________________________________________________________________________________________________________"<<endl;

cout<<endl;

}

balls--;

}
cin.get();
choice=2;
 save(total_scorefirst,total_scoresecond,bat_first,score,count,player_score,balls,bowl_first, ball_count,run1,run2,overs,SR,four,six,b,RR,maiden2,WB,NB,maiden,choice) ;  // FUNCTION CALL
   	FinalResult ( total_scorefirst,total_scoresecond,t1,t2,run1,run2,bat_first,bowl_first );   // FUNCTION CALL
}






//---------------------------------------------------------------FUNCTION FOR PRINTING FIRST INNINGS IN A  ------------------------------------------------------------------------------






int drawScoreCardFirst( int total_scorefirst,int total_scoresecond,string* bat_first, int score ,int i,int count,int* player_score,int balls,string innings,string* bowl_first,int* ball_count,int* run1,int* run2,int overs,int choice)
{
 
int maiden[11] = { 1,23,24,152,29,92,73,19,10,21,67},t1=0,t2=0;
int WB[11]={ 1,0,1,0,6,4,7,3,1,2,5};
int NB[11]={ 1,0,0,1,2,5,3,2,2,1,0};
int maiden2[11] = { 0,2,0,1,2,2,1,0,0,1,1};
int four[11]={0},six[11]={0};
float SR[11]={0};
float b = 0 ;
float RR;
   while (balls>0 && count <11 )
   {
   b= b + 0.167;

   ball_count[i]++;
	score = (rand()%8) - 1;
		total_scorefirst += score;  //----------------------------------CALCULATING SCORES---------------------------
RR=total_scorefirst/b;
       run1[i] = score + run1[i] ;

 if(score == 4 )
four[i]++;
else if ( score == 6 )
six[i]++;


   	if ( score == -1 )
		{
	player_score[i] = total_scorefirst;
	}

        if ( score == -1 )
        {
cout<<bat_first[i]<<"(out)"<<setw(30);
cout<<bowl_first[i]<<setw(15);
cout<<"out"<<setw(15);
cout<<ball_count[i]<<setw(15);
cout<<maiden[i]<<setw(15);
cout<<four[i]<<setw(15);
cout<<six[i]<<setw(15);
cout<<endl; 
cout<<"________________________________________________________________________________________________________________________________________________________"<<endl;
cout<<"|  TOTAL                     "<<int(b)<<" Ov.    (RR: "<<RR<<")            "<<total_scorefirst<<"/"<<count+1<<"                                                                                     |"<<endl;
cout<<"|_______________________________________________________________________________________________________________________________________________________|"<<endl;



        }
        else
	{
cout<<"-->"<<bat_first[i]<<setw(30);
cout<<bowl_first[i]<<setw(15);
cout<<score<<setw(15);
cout<<ball_count[i]<<setw(15);
cout<<maiden[i]<<setw(15);
cout<<four[i]<<setw(15);
cout<<six[i]<<setw(15);
cout<<endl;
cout<<"________________________________________________________________________________________________________________________________________________________"<<endl;
cout<<"|  TOTAL                     "<<int(b)<<" Ov.    (RR: "<<RR<<")            "<<total_scorefirst<<"/"<<count<<"                                                                                     |"<<endl;
cout<<"|_______________________________________________________________________________________________________________________________________________________|"<<endl;
	

		}
	
	
	if ( score == -1 )
		{
	player_score[i] = total_scorefirst;
	total_scorefirst++;
	count++;
	i++;
		}
	cin.get();
	
	
	
	system("clear");
	
	
	
cout<<endl;
	cout<<"  ^  FIRST INNINGS ("<<overs<<" overs maximum)"<<endl;
cout<<"_____________________________________________________________________________________________________________________________________________________________________"<<endl;
cout<<"|  BATTING                                                     R              B              M              4s              6s              SR                       |"<<endl;
cout<<"|____________________________________________________________________________________________________________________________________________________________________|"<<endl;

			for ( int j = 0 ; j < count ; j++ )
	{
   SR[j] = ((run1[j]+1.0 ) / ball_count[j]+0.001 ) * 100 ;
 
cout<<bat_first[j]<<"(out)"<<setw(30);
cout<<bowl_first[j]<<setw(15);
cout<<run1[j]+1<<setw(15);
cout<<ball_count[j]<<setw(15);
cout<<maiden[j]<<setw(15);
cout<<four[j]<<setw(15);
cout<<six[j]<<setw(15);
cout<<SR[j]<<setw(15);
cout<<endl;
	
	}
	
if(count == 11 || b>=overs ) { //----------------------------------PRINTING WHEN ALL PLAYERS WILL BE DISMISSED OR OVERS ARE FINISHED---------------------------
cout<<"_____________________________________________________________________________________________________________________________________________________________________"<<endl;
cout<<"|  TOTAL                     "<<int(b)<<" Ov     (RR: "<<RR<<")            "<<total_scorefirst<<"/"<<count<<"                                                                                                |"<<endl;
cout<<"|____________________________________________________________________________________________________________________________________________________________________|"<<endl;

cout<<endl<<endl<<endl;
cout<<"______________________________________________________________________________________________________________________________________________________________________"<<endl;
cout<<"|  BOWLING                                                     O              M              R              W              ECON              WD               NB      |"<<endl;
cout<<"|_____________________________________________________________________________________________________________________________________________________________________|"<<endl;


for ( int j = 0 ; j < count ; j++ )
	{

cout<<bowl_first[j]<<"     "<<right<<setw(30);
cout<<""<<setw(15);
cout<<ceil(ball_count[j]/6.0)<<setw(15);
cout<<maiden2[j]<<setw(15);
cout<<run1[j]+1<<setw(15);
cout<<rand()%3<<setw(15);
cout<<setprecision(2)<<(run1[j]+1 ) / (ball_count[j]/6.0)<<setw(15);
cout<<WB[j]<<setw(15);
cout<<NB[j]<<setw(15);

cout<<endl;



}
cout<<endl<<"______________________________________________________________________________________________________________________________________________________________________"<<endl;

cout<<endl;

}
balls--;
}	

cin.get();	
choice=1;
 save(total_scorefirst,total_scoresecond,bat_first,score,count,player_score,balls,bowl_first, ball_count,run1,run2,overs,SR,four,six,b,RR,maiden2,WB,NB,maiden,choice) ;
 drawScoreCardSecond( bat_first, total_scorefirst,  total_scoresecond, bowl_first,run1,run2,choice );   // FUNCTION CALL

}


    
    
   //----------------------------------------------------------------------------------DRIVER CODE-----------------------------------------------------------------------------------------------------------






int main()
{     // ---------------------------------------------------------------VARIABLE DECLARATIONS----------------------------------------------------- 
	srand(time(NULL));
	string bat_first[11] , bowl_first[11],innings;
      string pak [] = {"Mohammad Hafeez","Shahid Afridi","Younis khan","Misbah-ul-Haq","Abdul Razzaq","Mohammad Yousuf","Javed Miandad","Aamer sohail","Imran khan","Moin khan","Wasim Akram" };
      string india [] = {"Virat Kohli","Rohit sharma","Rishabh","Hardik","Ravindra","MS dhoni","Sachin Tendulkar","KL Rahul","Shami","Ravi","Kedar" };
	
	
	string* active_bat = new string [2];
	string* active_bowl = new string [2];
	
	int score = 0, total_scorefirst = 0 , total_scoresecond = 0, toss = 0 , i = 0,balls = 0,count = 0 ,player_score[11]={0},ball_count[11]={0},run1[11]={0},run2[11]={0},overs;
		int choice;
	
	string configuration("configuration.txt");  //------------------------------------------------- READING OVERS FROM FILE-----------------------------------------------------
	
	ifstream file(configuration);
	file>>overs;
	file.close();
	
	balls = overs * 6 ;
	
	toss = (rand()%2)  ;                             //----------------------------------TOSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS---------------------------
	
	if ( toss == 1)
	{   
	     innings = "PAKISTAN";
	     cout<<"Pakistan won the toss !"<<endl<<endl;
	    for ( int i = 0 ; i < 11 ; i++ )
	       { bat_first[i] = pak[i] ;
	          bowl_first[i] = india[i] ;
	       }
	       
	    for ( int i = 0 ; i<2 ; i++)
	    { active_bat[i]=bat_first[i];
	      active_bowl[i]=bowl_first[i];
	    }
	       
	       
	}
		else if ( toss == 0)
	{
	    innings= "INDIA";
	    cout<<"India won the toss !"<<endl<<endl;
	    for ( int i = 0 ; i < 11 ; i++ )
	      {  bat_first[i] = india[i] ;
	          bowl_first[i] = pak[i] ;
	      }
	      
	    for ( int i = 0 ; i<2 ; i++)
	    { active_bat[i]=bat_first[i];
	      active_bowl[i]=bowl_first[i];
	    }
	      
	      
	}
	

	
	ScoreCard(bat_first,score,total_scorefirst,total_scoresecond,i,player_score,count,balls,innings,bowl_first,ball_count,run1,run2,overs,choice);  // FUNCTION CALL
	
	
   while (1) 
   {
   
	cout<<endl;
	cout<<"__________________________________________________________________________________________"<<endl;
	cout<<endl;
	cout<<"Press 1 to Show First innings."<<endl;
	cout<<"Press 2 to Show Second innings."<<endl;
	cout<<"Press 3 to Save Match data."<<endl;
	cout<<"Press 4 to load a previous match data."<<endl;
	
	cout<<"Enter : ";
	cin>>choice;
	
	switch(choice)    //----------------------------------SWITCH STRUCTURE FOR MENU PRINTING AND FILE READING---------------------------
	{
	case 1:
	{
	system("clear");
	string line;
  ifstream file1 ("first.txt");
  if (file1.is_open())
  {
    while ( getline (file1,line) )
    {
      cout << line << endl;
    }
    file1.close();
  }

  else cout << "Unable to open file"; 
	}
	case 2:
	{
	system("clear");
	string lines;
  ifstream file2 ("second.txt");
  if (file2.is_open())
  {
    while ( getline (file2,lines) )
    {
      cout << lines << endl;
    }
    file2.close();
  }

  else cout << "Unable to open file"; 
	}
	case 3:
	cout<<"Saved."<<endl;
	case 4:
	break;
	}
	
	
	
}
	delete []active_bat;  // DELETING DYNAMIC POINTERS
	delete []active_bowl;
	return 0;
}

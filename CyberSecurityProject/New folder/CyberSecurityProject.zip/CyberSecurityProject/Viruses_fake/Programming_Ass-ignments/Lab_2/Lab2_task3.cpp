// including the required header files to run the program
#include<iostream>
using namespace std;

// Main function of the program
int main ()
{
    // Writing a program to interchange two variables
    int num1 = 6;
    int num2 = 9;

    // Making a temporary variable to store values in
    int temp = 0;

    // Printing to make clear what the values are right now

    cout << "Number1 =" << num1 << endl;
    cout << "Number2 =" << num2 << endl;

    // Interchanging values

    temp = num1;
    num1 = num2;
    num2 = temp;

    // Now printing the changed values

    cout << "The values have been changed" << endl;

    cout << "Number1 =" << num1 << endl;
    cout << "Number2 =" << num2 << endl;

    // Exiting the program

    return 0;
}
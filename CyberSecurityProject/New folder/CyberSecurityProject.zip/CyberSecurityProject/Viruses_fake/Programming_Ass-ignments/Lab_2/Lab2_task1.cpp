// including the required header files to run the program
#include<iostream>
using namespace std;

// Main function of the program
int main ()
{
    // Ass-igning values to variables at the time of declaring them
    int num1 = 2;
    int num2 = 6;

    float flt1 = 6.9;
    float flt2 = 8.5;

    // Now performing an operation on them

    int numbers_opt = num1 + num2;
    float floats_opt = flt1 * flt2;

    // Printing the variables now

    cout << "Numbers are: " << numbers_opt << endl;
    cout << "Floats are: " << floats_opt << endl; 

    // Exiting the program

    return 0;
}
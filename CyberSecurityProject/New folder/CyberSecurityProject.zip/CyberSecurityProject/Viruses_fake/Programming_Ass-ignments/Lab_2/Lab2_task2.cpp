// including the required header files to run the program
#include<iostream>
using namespace std;

// Main function of the program
int main ()
{
    // Program to perform all arithmetic operations
    int num1 = 6;
    int num2 = 9;

    float flt1 = 4.5;
    float flt2 = 8.2;

    // Now performing an operation on them

    int nums_opt = num1 + num2 - num1;
    float flts_opt = (flt1 * flt2) / flt1;

    // Printing the variables now

    cout << "Numbers are: " << nums_opt << endl;
    cout << "Floats are: " << flts_opt << endl; 

    // Exiting the program

    return 0;
}
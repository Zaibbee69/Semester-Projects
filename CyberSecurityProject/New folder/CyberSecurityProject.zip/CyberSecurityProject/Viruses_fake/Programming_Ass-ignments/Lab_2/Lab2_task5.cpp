// including the required header files to run the program
#include<iostream>
using namespace std;

// Main function of the program
int main ()
{
    // Writing a program that calculates the area and circumference of a circle

    // First declaring all the required variables

    int area , circumference;
    float radius;
    float pi_value = 3.141569;

    // Getting the radius from user

    cout << "Enter the radius of the circle: ";
    cin >> radius;

    // Using the formulae finding out the area and circumferences

    area = pi_value * ( radius * radius);
    circumference = 2 * pi_value * radius;

    // Printing the values on the screen

    cout << "The area of circle: " << area << endl;
    cout << "The circumference of circle: " << circumference << endl;
    
    // Exiting the program

    return 0;
}   
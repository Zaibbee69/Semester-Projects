// Including the required header files
#include<iostream>
using namespace std;

// Write a C++ program to compute the telephone bill for the city consumers
int main()
{
    // Declaring the required variables
    int numberOfCalls;
    float bill;

    // First getting the number of calls made from the user
    cout << "State the number of calls made: -" << endl;
    cin >> numberOfCalls;

    // Now applying conditions 
    if ( numberOfCalls <= 100 )
    {
        int meterCharges = 250;
        float ratePerCall = 0.80;

        // Now calculating the bill
        bill = meterCharges + ( numberOfCalls * ratePerCall );
    }

    else if ( numberOfCalls > 100 && numberOfCalls <= 250 )
    {
        int meterCharges = 350;
        float ratePerCall = 1.00;

        // Now calculating the bill
        bill = meterCharges + ( numberOfCalls * ratePerCall );
    }

    else if ( numberOfCalls > 250 )
    {
        int meterCharges = 500;
        float ratePerCall = 1.25;
        
        // Now calculating the bill
        bill = meterCharges + ( numberOfCalls * ratePerCall );
    }

    // Now printing the total bill made
    cout << "Your Bill Amount is = " << bill << endl;

    // Exiting the program
    return 0;
}
#include <iostream>

int main() {
    const int principal = 100000;
    const int years = 10;
    double interestRate = 0.06; // starting interest rate

    std::cout << "Yearly Amounts Available for Different Interest Rates\n\n";
    std::cout << "Interest Rate (%)   Year 1     Year 2     Year 3     Year 4     Year 5     Year 6     Year 7     Year 8     Year 9     Year 10\n";

    for (int i = 0; i < 7; ++i) {
        double amount = principal;
        std::cout.precision(2);
        std::cout << std::fixed << interestRate * 100 << "%";
        for (int j = 0; j < 10; ++j) {
            amount += interestRate * amount;
            std::cout << "   " << amount;
        }
        std::cout << std::endl;
        interestRate += 0.01; // incrementing interest rate by 1%
    }

    return 0;
}

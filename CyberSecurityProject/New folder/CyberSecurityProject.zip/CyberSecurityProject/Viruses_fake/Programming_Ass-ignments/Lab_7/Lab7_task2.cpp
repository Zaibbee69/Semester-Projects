// Including the required header files
#include<iostream>
using namespace std;

// Create the equivalent of a four - function calculator
int main()
{
    // We will be using goto statement for this purpose
    Start:
        // Declaring the required variables
        float firstNumber , secondNumber;
        char selOperator , choiceSelector;

        // First asking the user for the numbers and the operator

        cout << "Enter the first number: ";
        cin >> firstNumber;

        cout << "Enter the second number: ";
        cin >> secondNumber;

        cout << "Enter your selected operator ( + , - , * , / ): ";
        cin >> selOperator;

        // Now using a Switch statement to iterate over all the operators
        switch ( selOperator )
        {
            case '+': // If Addition operator selected
            cout << "Addition of " << firstNumber << " and " << secondNumber << " is : " << firstNumber + secondNumber << endl;
            break;

            case '-': // If Subtraction operator selected
            cout << "Subtraction of " << firstNumber << " and " << secondNumber << " is : " << firstNumber - secondNumber << endl;
            break;

            case '*': // If Multiplication operator selected
            cout << "Multiplication of " << firstNumber << " and " << secondNumber << " is : " << firstNumber * secondNumber << endl;
            break;

            case '/': // If Division operator selected
            cout << "Division of " << firstNumber << " and " << secondNumber << " is : " << firstNumber / secondNumber << endl;
            break;

            default:
            cout << "Invalid operator selected" << endl;
            break;
        }

    // Now asking the user if they want to continue

    cout << "Do you want to continue? ( y / n )" << endl;
    cin >> choiceSelector;

    // Using Goto statement for this purpose

    if ( choiceSelector == 'y' || choiceSelector == 'Y' )
    {
        goto Start;
    }
    
    // Exiting the program
    return 0;
}
// Including the required header files
#include<iostream>
using namespace std;

// Write a program that displays a triangle using a for loop
int main()
{
    // Declaring the required variables
    int loopNumber = 10;

    // Now using a for loop to make the triangle
    for ( int i = 1 ; i <= loopNumber ; i ++ )
    {
        for ( int j = 1 ; j <= i ; j ++ )
        {
            cout <<  "  " << j;
        }
        cout << endl;
    }
}
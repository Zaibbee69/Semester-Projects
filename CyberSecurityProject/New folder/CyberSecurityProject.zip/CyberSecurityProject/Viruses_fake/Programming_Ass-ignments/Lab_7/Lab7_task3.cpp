// Including the required header files
#include<iostream>
using namespace std;

// Write a program that displays a an arrow head like triangle using a for loop
int main()
{
    // Declaring the required variables
    int loopNumber = 6;
    char looperChar = '*';

    // Now using a printing first part of the triangle
    for ( int i = 1 ; i <= loopNumber ; i ++ )
    {
        for ( int j = 1 ; j <= i ; j ++ )
        {
            cout <<  "  " << looperChar;
        }
        cout << endl;
    }

	// Now the second part of the triangle
	for ( int i = loopNumber-1 ; i >= 1 ; i -- )
	{
		for ( int j = 1 ; j <= i ; j ++ )
		{
			cout << "  " << looperChar;
		}
		cout << endl;
	}
}
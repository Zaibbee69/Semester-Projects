// Including the required header files
#include<iostream>
using namespace std;

/* Main Function of the program */
int main ()
{
    // Printing the desired output
    cout<<"SEPF-121 \n Programming Fundamentals";
    
    // Exiting Function
    return 0;
}
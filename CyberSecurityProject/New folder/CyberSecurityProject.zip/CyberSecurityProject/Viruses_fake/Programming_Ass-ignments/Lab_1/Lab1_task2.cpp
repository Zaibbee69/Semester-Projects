// Including the required header files
#include<iostream>
using namespace std;

/* Main Function of the program */
int main ()
{
    // Printing the desired output
    cout<<"******\n*****\n****\n***\n**\n*";
    
    // Exiting Function
    return 0;
}
// Including the required header files
#include<iostream>
using namespace std;

/* Main Function of the program */
int main ()
{
    // Printing the desired output in which 6 esc statemtents are being used
    cout<<"Ms.Maryam Imtiaz \n teaches us \t \"Programming Fundamentals\" \a \n I enjoy her class alot. \b";
    
    // Exiting Function
    return 0;
}
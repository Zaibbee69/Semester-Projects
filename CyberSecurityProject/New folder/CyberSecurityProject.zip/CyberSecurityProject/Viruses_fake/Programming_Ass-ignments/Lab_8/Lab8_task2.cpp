// Including the required header files
#include<iostream>
using namespace std;

// Implement a program that converts Celsius to Fahrenheit , until the user asks to stop
int main()
{
    // Declaring the required variables
    int celsius;
    float fahrenheit;
    char choiceMaker;

    do
    {
        // Asking the user for cesius value
        cout << "Enter the Celsius in degrees : ";
        cin >> celsius;

        // Now inputing formula for conversion
        fahrenheit = ( celsius * 9 / 5 ) + 32;

        // Now just outputing the converted value
        cout << "Fahrenheit : " << fahrenheit << endl << endl;

        // Now asking the user if they want to continue
        cout << "Do you want to keep converting values? ( Y | N ) : ";
        cin >> choiceMaker;
    }
    while ( choiceMaker == 'Y' || choiceMaker == 'y' );

    // Exiting the program
    return 0;


}
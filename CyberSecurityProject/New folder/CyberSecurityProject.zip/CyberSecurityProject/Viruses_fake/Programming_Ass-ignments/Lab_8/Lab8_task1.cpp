// Including the required header files
#include<iostream>
using namespace std;

// Write a program that simulates a student grading system and keeps asking the user for numbers
int main()
{
    // Declaring the required variables
    int totalSubjects = 5;
    int subjectMarks;
    int sumOfSubjects = 0;
    char choiceMaker;
    float average;

    // We will be asking the user repeatedly by using a goto statement. Why you ask? CAUSE WE CAN!!
    Start:


        // Now asking the user for 5 subject marks using a for loop
        for ( int i = 1; i <= totalSubjects; i ++)
        {
            cout << "Enter the marks of the " << i << " Subject : ";
            cin >> subjectMarks;

            // Now just adding all the subject marks 
            sumOfSubjects += subjectMarks;
        }

        // Ok now finding the average of the marks
        average = sumOfSubjects / totalSubjects;

        // Printing the obtained average
        cout << "Average is : " << average << endl << endl;

        // Now telling the user that the student marks average have been found
        cout << "Average of the current student has been found !!!" << endl << endl;

        // Now asking the user if they want to continue
        cout << "Do You want to calculate for another student? ( Y | N ) : ";
        cin >> choiceMaker;
        cout << endl;

        // Now making the decision
        if ( choiceMaker == 'Y' || choiceMaker == 'y' )
        {
            goto Start;
        }
        else
        {
            return 0;
        }
}
// Including the required header files
#include<iostream>
using namespace std;

#define MaxLoopPatternMaker 5

// Write a program to display a certain pattern
int main()
{
    for( int i = 1; i <= MaxLoopPatternMaker; i ++ )
    {
        for ( int j = 1; j <= MaxLoopPatternMaker - i ; ++ j ) 
        {
            cout << " ";
        }
        for ( int j = 1; j <= i; ++ j )
        {
            cout << i << " ";
        }
        cout << endl;  
    }
}
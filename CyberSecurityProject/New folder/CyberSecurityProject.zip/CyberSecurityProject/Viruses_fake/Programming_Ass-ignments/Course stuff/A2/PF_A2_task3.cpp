// Including the required header files
#include<iostream>
using namespace std;

// Write a program that takes three numbers from the user and displays the largest number
int main()
{
    // Declaring the required variales
    int decimal;
    int remainder;
    int binary = 0;
    int product = 1;

    // Getting the number from the user
    cout << "Enter a Number : ";
    cin >> decimal;

    // Now using a while loop to convert the number to a binary digit
    while ( decimal > 0 )
    {
        remainder = decimal % 2; // First finding the reminder of the number
        binary = binary + ( remainder * product );
        decimal /= 2; // Dividing by 2 cause binary digit is of 0 , 1
        product *= 10;
    }
    // Printing the acquired binary digit
    cout << "The binary form is : " << binary << endl;
 
}
// Including the required header files
#include<iostream>
using namespace std;

// Defining a standard for the loop iteratable to be changeable
#define totalNumberLooper 3

// Write a program that takes three numbers from the user and displays the largest number
int main()
{
    // Declaring the required variales
    double number1 , number2 , number3;
    double numberStorer;
    double resultHolder;

    // Getting the numbers from the user using a for loop Cause we can!!!
    for ( int i = 1 ; i <= totalNumberLooper ; i ++ )
    {
        cout << "Enter your number " << i << " : ";
        cin >> numberStorer;

        if ( i == 1 )
        {
            number1 = numberStorer; 
        }
        else if ( i == 2 )
        {
            number2 = numberStorer;
        }
        else
        {
            number3 = numberStorer;
        }
    }

    // Now making a check wether the number are positive numbers
    if ( number1 < 0 || number2 < 0 || number3 < 0 )
    {
        cout << "Numbers must be of positive value" << endl; 
    }

    // Now checking which of the numbers is bigger
    resultHolder = number1;

    if ( number2 > resultHolder )
    {
        resultHolder = number2;
    }
    if ( number3 > resultHolder )
    {
        resultHolder = number3;
    }

    // Now just printing the highest number
    cout << "The Highest number is " << resultHolder << endl;

    // Now just exiting the program

    return 0;

 
}
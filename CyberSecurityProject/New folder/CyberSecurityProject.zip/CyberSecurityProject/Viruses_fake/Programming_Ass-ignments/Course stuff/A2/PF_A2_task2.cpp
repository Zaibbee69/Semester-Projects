// Including the required header files
#include<iostream>
using namespace std;

// Write a program that calculates and displays the yearly amount amount avaliable
int main()
{
    // Declaring the required variables
    const double bank_invested = 100000;
    double amount;
    const int years_invested = 10;
    double interest_rates_start = 0.06;
    double interest_rates_end = 0.12;

    // Using the first for loop for going through all the investment percentages
    for (interest_rates_start ; interest_rates_start <= interest_rates_end ; interest_rates_start +=0.01)
    {
        amount = bank_invested;
        for (int i = 0; i < years_invested ; i ++ )
        {
            amount += interest_rates_start * amount;
        }

        cout << "The yearly amount avaliable at " << interest_rates_start * 100 << "\% is " << amount << endl;
    }
}
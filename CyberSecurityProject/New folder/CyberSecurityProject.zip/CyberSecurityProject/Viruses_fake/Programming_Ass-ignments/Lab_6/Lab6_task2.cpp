// Including the required header files
#include<iostream>
using namespace std;

// Write a program to print the reverse of any digits
int main()
{
    // Declaring the required variables
    double income , expenses , taxDeductions , taxableIncome , amountOwed;
    char choiceContinuer;

    // Using a do while loop for this purpose to constantly ask the user
    do
    {
        // Getting the values from user
        cout << "Enter Your Income : ";
        cin >> income;

        cout << "Enter Your Expenses : ";
        cin >> expenses;

        cout << "Enter Your Tax-Deductions : ";
        cin >> taxDeductions;

        // Now calculating taxable_income
        taxableIncome = income - expenses - taxDeductions;

        // Now if the taxable_income is less than zero than user owes no amount
        if ( taxableIncome <= 0 )
        {
            amountOwed = 0;
            cout << "You Owe No Amount and your taxable income is : " << taxableIncome << endl;
        }
        else
        {
            amountOwed = 0.20 * taxableIncome;
            cout << "Your Amount Owed is : " << amountOwed << " And your taxable income is : " << taxableIncome << endl;
        }

        // Now asking the user if they want to continue
        cout << "Do You want to keep calculating taxable income (Y/N)? ";
        cin >> choiceContinuer;
    }
    while ( choiceContinuer == 'Y' || choiceContinuer == 'y' );

    // Exiting the program
    return 0;
}
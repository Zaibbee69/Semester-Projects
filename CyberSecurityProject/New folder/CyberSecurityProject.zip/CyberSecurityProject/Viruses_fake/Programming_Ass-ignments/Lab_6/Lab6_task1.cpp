// Including the required header files
#include<iostream>
using namespace std;

// Write a program to print the reverse of any digits
int main()
{
    // Declaring the required variables
    int number;
    int reversedNumber = 0;

    // First getting the number from the user
    cout << "Enter a number : ";
    cin >> number;
    
    cout << "Reversed Number : "; 

    // Now reversing the digits using while loop
    while ( number != 0 )
    {
        reversedNumber = number % 10; // Getting the last digit
        cout << reversedNumber; // Prinitng the acquired digit 
        number /= 10; // Cutting off the last digit
    }
    cout << endl;

    // Exiting the program
    return 0;
}
// Including the required the header files
#include<iostream>
using namespace std;

// Write a program to calculate factorial using for loop
int main ()
{
    // Declaring the required variables
    int fact_num;
    unsigned long factorial = 1;

    // Getting number from user
    cout << "Enter number : " << endl;
    cin >> fact_num;

    // Now using for loop basically multiplying by int as a fact = 1*2*3*4....
    for ( int i = 1 ; i <= fact_num ; i ++)
    {
        factorial *= i;
    }

    // Printing factorial
    cout << "Factorial of " << fact_num << " is : " << factorial << endl;

    // Exiting function
    return 0;


}
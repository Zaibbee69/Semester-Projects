// Including the required the header files
#include<iostream>
using namespace std;

// Write a program using while loop which displays alphabets from Z to A using while loop
int main ()
{
    // Declaring the required variables
    char alphabet = 'Z';

    // Now using a while loop as a characters on ASCII table are 1 value apart from one another
    while ( alphabet >= 'A' )

    {
        cout << "Alphabet : " << alphabet << endl;
        alphabet --;
    }

    // Exiting function
    return 0;
}
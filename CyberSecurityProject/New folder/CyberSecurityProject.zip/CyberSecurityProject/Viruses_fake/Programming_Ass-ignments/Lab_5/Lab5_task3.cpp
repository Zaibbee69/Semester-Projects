// Including the required the header files
#include<iostream>
using namespace std;

// Write a program to find the average of N numbers using while loop
int main ()
{
    // Declaring the required variables
    int n;
    int sum = 0;
    int counter = 1;
    float average;

    // Getting the number from user
    cout << "Enter a number : " << endl;
    cin >> n;

    // Now using a while loop
    while ( counter <= n )
    {
        sum = sum + counter;
        counter ++;
    }

    cout << "Sum : " << sum << endl; 

    // Now finding average
    average = sum / n;
    cout << "Average is : " << average << endl;

    // Exiting function
    return 0;
}
// Including the required header files
#include<iostream>
using namespace std;

// Write a simple ten quiz program which asks the user for MCQS and in the end answers the following questions and gives correct answers
int main()
{
    // Declaring the required variables
    int result = 0;
    char mcq;

    // Now making the 10 choice mcqs question

    // QUESTION # 1
    cout << "Question 1 : What is the capital of Pakistan : " << endl;
    cout << "(a) Faislabad. " << "(b) Lahore. " << endl;
    cout << "(c) Islamabad. " << "(d) Karachi. " << endl;
    cout << "Answer : ";
    cin >> mcq;

    if (mcq == 'c')
    {
        result ++;
    }
    cout << result << endl;
}
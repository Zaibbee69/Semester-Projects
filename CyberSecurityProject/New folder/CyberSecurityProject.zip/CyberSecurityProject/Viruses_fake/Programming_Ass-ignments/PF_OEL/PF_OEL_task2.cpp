// Including the required header files
#include<iostream>
using namespace std;

// Write a menu driven program which allows the user to perform certain operations occording to their own desire
int main()
{
    // Declaring the required variables
    int factorial = 1;
    int armStrong;
    int number;
    int holder;
    int remainder;
    int sum = 0;
    char choiceMaker;

    // Now asking the user wether which choice they want to make
    cout << endl << endl;
    cout << "+-----------------------Menu-------------------------+" << endl;
    cout << "Which operation do you want to do? " << endl << endl;
    cout << "(a) Calculate the Factorial. " << "(b) Check Armstrong. " << endl;
    cout << "Choice : ";
    cin >> choiceMaker;
    cout << endl;

    // Now based on the decision making a choice

    // ---------------------FACTORIAL PART---------------------
    if ( choiceMaker == 'a' )
    {
        cout << "+----------------------Calculating Factorial-----------------------+" << endl << endl;
        // Taking the number from the user
        cout << " Enter a number : ";
        cin >> number;

        // Making check for factorial
        if ( number <= 0 )
        {
            cout << "Number cant be negative values " << endl;
            return 0;
        }

        // Using for loop for factorial
        for ( int i = 1 ; i <= number ; i ++)
        {
            factorial *= i;
        }

        // Printing the acquired result
        cout << "Factorial : " << factorial << endl;

        // Exiting the program 
        return 0;
    }

    // --------------------ARMSTRONG PART--------------------------

    else if ( choiceMaker == 'b' )
    {
        cout << "+------------------------Checking for Armstrong Number-----------------------+" << endl << endl;
        // First getting input from the user
        cout << "Enter a Number : ";
        cin >> number;
        holder = number;

        // Using a while loop for armstrong purpose
        while ( number != 0 )
        {
            // Getting the last digit of the number
            remainder = number % 10; 

            // Adding that digit to the sum
            sum = sum + ( remainder * remainder * remainder );

            // Now cutting of the last digit of the number
            number /= 10;
        }
            // Now making check wether the number was armstrong or not
            if ( sum == holder )
            {
                cout << holder << " is an Armstrong number." << endl << endl;
            }
            else
            {
                cout << holder << " is not an Armstrong number" << endl << endl;
            }
    }
}
// Including the required header files
#include<iostream>
using namespace std;

// Write a simple ten quiz program which asks the user for MCQS and in the end answers the following questions and gives correct answers
int main()
{
    // Declaring the required variables
    int result = 0;
    char mcq;

    // Now making the 10 choice mcqs question

    // QUESTION # 1
    cout << "Question 1 : Is Ms. Maryam the best teacher? : " << endl;
    cout << "(a) Yes. " << "(b) No. " << endl;
    cout << "(c) Sometimes. " << "(d) Only on Monday's. " << endl;
    cout << "Answer : ";
    cin >> mcq;
    cout << endl;

    // making check for question 1

    if (mcq == 'a')
    {
        result ++;
    }

    // QUESTION # 2
    cout << "Question 2 : Do Italians like pizza? : " << endl;
    cout << "(a) Yes. " << "(b) No. " << endl;
    cout << "(c) Only Pineapple on pizza. " << "(d) Burgers. " << endl;
    cout << "Answer : ";
    cin >> mcq;
    cout << endl;

    // making check for question 2

    if (mcq == 'a')
    {
        result ++;
    }

    // QUESTION # 3
    cout << "Question 3 : What is the capital of Pakistan? : " << endl;
    cout << "(a) Faislabad. " << "(b) Lahore. " << endl;
    cout << "(c) Islamabad. " << "(d) Karachi. " << endl;
    cout << "Answer : ";
    cin >> mcq;
    cout << endl;

    // making check for question 3

    if (mcq == 'c')
    {
        result ++;
    }   


    // QUESTION # 4
    cout << "Question 4 : Who started WW2? : " << endl;
    cout << "(a) Saddam Hussain. " << "(b) Hitler. " << endl;
    cout << "(c) Einstein. " << "(d) Joseph Stalin. " << endl;
    cout << "Answer : ";
    cin >> mcq;
    cout << endl;

    // making check for question 4

    if (mcq == 'b')
    {
        result ++;
    }

    // QUESTION # 5
    cout << "Question 5 : What is the chemical formula of water? : " << endl;
    cout << "(a) CO2. " << "(b) NH3. " << endl;
    cout << "(c) H2SO4. " << "(d) H20. " << endl;
    cout << "Answer : ";
    cin >> mcq;
    cout << endl;

    // making check for question 5

    if (mcq == 'b')
    {
        result ++;
    }

    // QUESTION # 6
    cout << "Question 6 : Which is the largest desert in the world : " << endl;
    cout << "(a) Sahara Desert. " << "(b) Atlantic Desert. " << endl;
    cout << "(c) Euphoria. " << "(d) Oasis Desert. " << endl;
    cout << "Answer : ";
    cin >> mcq;
    cout << endl;

    // making check for question 6

    if (mcq == 'a')
    {
        result ++;
    }

    // QUESTION # 7
    cout << "Question 7 : What is the national dish of Pakistan? : " << endl;
    cout << "(a) Biryani. " << "(b) Lamb Meat. " << endl;
    cout << "(c) Nihaari. " << "(d) Daal Chawal. " << endl;
    cout << "Answer : ";
    cin >> mcq;
    cout << endl;

    // making check for question 7

    if (mcq == 'c')
    {
        result ++;
    }

    // QUESTION # 8
    cout << "Question 8 : What is name of SOP of Ghazali Block? : " << endl;
    cout << "(a) Ahsan Arif. " << "(b) Donald Trump. " << endl;
    cout << "(c) Gaandhi. " << "(d) Batman. " << endl;
    cout << "Answer : ";
    cin >> mcq;
    cout << endl;

    // making check for question 8

    if (mcq == 'a')
    {
        result ++;
    }

    // QUESTION # 9
    cout << "Question 9 : What is the name of fish mostly used in sushi : " << endl;
    cout << "(a) Tuna. " << "(b) Eel. " << endl;
    cout << "(c) Brass. " << "(d) Salmon " << endl;
    cout << "Answer : ";
    cin >> mcq;
    cout << endl;

    // making check for question 9

    if (mcq == 'd')
    {
        result ++;
    }

    // QUESTION # 10
    cout << "Question 10 : In which year did the queen of England died? : " << endl;
    cout << "(a) 1969. " << "(b) 2016. " << endl;
    cout << "(c) 2002. " << "(d) 2023. " << endl;
    cout << "Answer : ";
    cin >> mcq;
    cout << endl;

    // making check for question 10

    if (mcq == 'd')
    {
        result ++;
    }

    // Now outputing the users result

    cout << "Total Marks Obtained : " << result << endl;
}
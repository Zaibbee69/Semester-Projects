// Including the required header files
#include<iostream>
using namespace std;

// Function declaration
void trianglePattern();

// Write a program which prints a certain triangle star pattern using functions
int main()
{
    // Calling the function
    trianglePattern();
}

// Now making the triangle function
void trianglePattern()
{
    // Defining a standard for pattern forming which can be used to make the pattern bigger
    int pattern_expand = 5;

    // This loop prints the base
    for( int i = 0; i <= pattern_expand; i ++ )
    {
        // This loop will print the white spaces for character cause how a triangle shape is
        for( int j = 0; j <= i ; j ++ )
        {
            cout << " ";
        }

        // This loop will print the star patterns on the screen
        for( int k = 0; k <= pattern_expand - i; k ++ )
        {
            cout << "* ";
        }
        // Now printing stuff on new line
        cout << endl;
    }
}
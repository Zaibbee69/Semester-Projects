// First including all the required header files
#include<iostream>
using namespace std;

// Function declaration
void table_maker();

// Write a function which produces a table of the numbers from 1 to 10
int main()
{
    // Calling the function for table making
    table_maker();
}

// Making the table function
void table_maker()
{
    // Making a header for the tables
    cout << "+----------Multiplication Tables----------+" << endl << endl;

    // This loop will be used for the multipiled number
    for ( int i = 1; i <= 10; i ++ )
    {   
        // This loop will be used to be for the number to be multiplied with
        for ( int j = 1; j <= 10; j ++)
        {
            cout << i << " Multiplied by " << j << " is : " << i * j << endl;
        }

        cout << "+----------------------------------------+" << endl;
    }
}

// Including the required header files
#include<iostream>
using namespace std;

// Function declaration
bool vowelChecker(char alphabet);

// Write a program which detects wether a char is a vowel or not
int main()
{
    // Declaring the required variables
    char alphabet;
    bool checker = false;

    // Getting the alphabet from the user
    cout << "Enter your alphabet : ";
    cin >> alphabet;

    // Now calling the function 
    checker = vowelChecker(alphabet);

    // Now making the decision
    if ( checker == true )
    {
        cout << "The alphabet is a vowel ! " << endl;
    }
    else
    {
        cout << "The alphabet is not a vowel ! " << endl;
    }
}

// The vowel checker function
bool vowelChecker(char alphabet)
{
    // Declaring the required variables
    char alpha;
    bool validator = false;
    // First making the alphabet to lower case so we don't have to check for upper case alphabets also
    alpha = tolower(alphabet);

    // Now we will we using switch case statement for this purpose
    switch(alpha)
    {
        case 'a':
        validator = true;
        break;

        case 'e':
        validator = true;
        break;

        case 'i':
        validator = true;
        break;

        case 'o':
        validator = true;
        break;

        case 'u':
        validator = true;
        break;

        default:
        validator = false;
        break;
    }

    // Now returning the bool value
    return validator;
}
// Including the required header files
#include<iostream>
using namespace std;

// Function declaration
bool primeChecker(int number);

// Write a program which detects wether a char is a vowel or not
int main()
{
    // Declaring the required variables
    int number;
    bool result;

    // First getting the number from the user
    cout << "Enter a number : ";
    cin >> number;

    // Now calling the function on the number
    result = primeChecker(number);

    // Printing the result based on condition
    if ( result == true )
    {
        cout << "The number is a prime number ! " << endl;
    }
    else
    {
        cout << "The number is not a prime number ! " << endl;
    }

}

// The vowel checker function
bool primeChecker(int number)
{
    // Declaring the required variables
    bool result = false;

    // Checking if number is prime
    for ( int i = 2; i * i <= number; i ++ )
    {
        if ( number % 2 == 0 )
        {
            return result = false;
        }
    }

    return true;

}
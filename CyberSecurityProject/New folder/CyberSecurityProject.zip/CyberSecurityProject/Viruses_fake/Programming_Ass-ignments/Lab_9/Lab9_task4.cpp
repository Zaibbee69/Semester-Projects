// Including the required header files
#include<iostream>
using namespace std;

// Function declaration
int factorial(int number);

// Write a function that takes the factorial of a number
int main()
{
    // Declaring the required variables
    int number;
    int result;

    // Getting the number from the user
    cout << "Enter a number : ";
    cin >> number;

    // Calling the function to find reverse digit
    result = factorial(number);

    // Now printing the result
    cout << "Factorialized : " << result << endl;

    // Exiting the program now
    return 0;
}

int factorial(int number)
{
    // Declaring the required variables
    int factorial = 1;

    // We will we using a for loop for factorial
    for ( int i = 1; i <= number; i ++)
    {
        factorial *= i;
    }

    return factorial;
}
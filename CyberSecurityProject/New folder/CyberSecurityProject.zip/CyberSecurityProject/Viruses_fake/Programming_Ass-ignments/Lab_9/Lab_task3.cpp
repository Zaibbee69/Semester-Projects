// Including the required header files
#include<iostream>
using namespace std;

// Function declaration
int reversed_digit(int digit);

// Write a function that takes an integer and returns its digits reversed as an int
int main()
{
    // Declaring the required variables
    int digit;
    int result;

    // Getting the number from the user
    cout << "Enter a number : ";
    cin >> digit;

    // Calling the function to find reverse digit
    result = reversed_digit(digit);

    // Now printing the result
    cout << "Reversed Digit : " << result << endl;

    // Exiting the program now
    return 0;
}

int reversed_digit(int digit)
{
    // Declaring the required variables
    int remainder = 0;
    int reversed_digit = 0;

    // We will we using a while loop for reversed number
    while ( digit != 0 )
    {
        // First getting the last digit of the number
        remainder = digit % 10;

        // Now we will be storing that digit in an int using a formula
        reversed_digit = reversed_digit * 10 + remainder;

        // Now cutting off the last digit of the number
        digit /= 10;
    }

    // Now returning the reversed digit to main program
    return reversed_digit;
}
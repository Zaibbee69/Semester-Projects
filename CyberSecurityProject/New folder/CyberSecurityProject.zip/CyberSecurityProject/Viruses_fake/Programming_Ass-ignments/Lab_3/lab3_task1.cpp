// Including the required header files
#include<iostream>
using namespace std;

// Write a program to find out wether the given number is even or odd
int main()
{
    // Declaring the required variables
    int number;

    // First getting input from user about the number
    cout << "Enter Your Number:-  " << endl;
    cin >> number;
    
    // Now checking wether the number is even or odd
    if ( number % 2 == 0)
    {
        cout << number << " is an even number" << endl;
    }
    else
    {
        cout << number << " is an odd number" << endl;
    }

    // Exiting the program
    return 0; 
}
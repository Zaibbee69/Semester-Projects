int main()
{
    // Declaring the required variables
    int num1 , num2;
    char operator_type;

    // First getting the two numbers from the user
    cout << "Enter the number 1 :- " << endl;
    cin >> num1;

    cout << "Enter the number 2 :- " << endl;
    cin >> num2;

    // Now getting the operation type from the user
    cout << "Choose your operation ( + , - , * , / ) :- " <<endl;
    cin >> operator_type;

    // Now using a switch statement to iterate

    switch (operator_type)
    {
        // In case of addition
        case '+':
        cout << "Addition :- " << ( num1 + num2 ) << endl;
        break;

        // In case of subtraction
        case '-':
        cout << "Subtraction :- " << ( num1 - num2 ) << endl;
        break;

        // In case of multiplication
        case '*':
        cout << "Multiplication :- " << ( num1 * num2 ) << endl;
        break;

        // In case of division
        case '/':
        cout << "Division :- " << ( num1 / num2 ) << endl;
        break;

        // Default case
        default:
        cout << "Invalid operator given" << endl;
    }
    
    // Exiting the program
    return 0; 
}
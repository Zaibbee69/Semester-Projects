// Including the required header files
#include<iostream>
using namespace std;

// Write a program to grade the student on his/her marks (this time using nested if else statements)
int main()
{
    // Declaring the required variables
    int total_marks = 500; // Reason cause one subject has a total of 100 marks
    float sub1 , sub2 , sub3 , sub4 , sub5 , sub_total;
    float percentage;
    char grade;

    // Now getting the marks of subjects one by one from user
    cout << "Enter marks of the first subject" << endl;
    cin >> sub1;

    cout << "Enter marks of the second subject" << endl;
    cin >> sub2;

    cout << "Enter marks of the third subject" << endl;
    cin >> sub3;

    cout << "Enter marks of the fourth subject" << endl;
    cin >> sub4;

    cout << "Enter marks of the fifth subject" << endl;
    cin >> sub5;

    // Finding total marks of all subjects of student
    sub_total = sub1 + sub2 + sub3 + sub4 + sub5;
   
    // Now putting percentage formulae
    percentage = ( sub_total / total_marks) * 100;

    // Now finding the Grade of the student using percentage
        if (percentage >= 80) {
        grade = 'A';
    } else {
        if (percentage >= 70 && percentage <= 80) {
            grade = 'B';
        } else {
            if (percentage >= 60 && percentage <= 70) {
                grade = 'C';
            } else {
                if (percentage >= 50 && percentage <=60) {
                    grade = 'D';
                } else {
                    grade = 'F';
                }
            }
        }
    }

    // Now just printing the grade
    cout << "You Got Grade " << grade << endl;

    // Exiting the program
    return 0; 
}
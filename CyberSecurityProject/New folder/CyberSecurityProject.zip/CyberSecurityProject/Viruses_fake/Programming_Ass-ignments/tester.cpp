#include <iostream>
using namespace std;

int main() {
    int rows = 5;

    // Loop through each row
    for (int i = 1; i <= rows; ++i) {
        // Print the numbers in each row
        for (int j = 1; j <= i; ++j) {
            cout << i << " ";
        }
        cout << endl;
    }

    return 0;
}

// Including the required header files
#include<iostream>
using namespace std;

// Write a program to find the average of N numbers using while loop enter num, sum = 15, avearfge=
int main()
{
    // Declaring the required variables
    int number , average , sum ;
    int temp = 0;

    // Getting the number from user
    cout << "Enter your number = " << endl;
    cin >> number;

    while ( average != 0 )
    {
        temp = number;
        number -= 1;
        sum = number + sum;
        cout << sum;
    }
}

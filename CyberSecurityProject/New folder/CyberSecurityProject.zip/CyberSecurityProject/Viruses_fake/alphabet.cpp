// Including the required header files
#include<iostream>
using namespace std;

// Write a program using while loop which displays alphabets from z to a
int main()
{
    // Declaring the required variables
    char alphabets = 'z';

    // Using while loop
    while ( alphabets >= 'a')
    {
        cout << "Alphabet is = " << alphabets << endl;
        alphabets --;
    }
    return 0;
}

// Including the required header files
#include<iostream>
using namespace std;

// Write a program to print the factorial of any number
int main()
{
    // Declaring the required variables
    int fact = 5;
    int number = 1;

    for ( int i = 0 ; i <= 5 ; i ++)
    {
        if ( fact == 0 )
        {
            return fact;
        }
        return fact * number;
    }

    cout << "Factorial" << fact << endl;
}

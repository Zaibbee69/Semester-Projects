// Including the required header files
#include<iostream>
using namespace std;

// Create the equivalent of a four - function calculator
int main()
{
    // Declaring the required variables
    float firstNumber , secondNumber;
    char selOperator , choiceSelector;

    // First asking the user for the numbers and the operator

    decisionMaker:
        cout << "Enter the first number: ";
        cin >> firstNumber;

        cout << "Enter the second number: ";
        cin >> secondNumber;

        cout << "Enter your selected operator ( + , - , * , / ): ";
        cin >> selOperator;

        // Now using a Switch statement to iterate over all the operators
        switch ( selOperator )
        {
            case '+': // If Addition operator selected
            cout << "Addition of " << firstNumber << " and " << secondNumber << " is : " << firstNumber + secondNumber << endl;
            break;

            case '-': // If Subtraction operator selected
            cout << "Subtraction of " << firstNumber << " and " << secondNumber << " is : " << firstNumber - secondNumber << endl;
            break;

            case '*': // If Multiplication operator selected
            cout << "Multiplication of " << firstNumber << " and " << secondNumber << " is : " << firstNumber * secondNumber << endl;
            break;

            case '/': // If Division operator selected
            cout << "Division of " << firstNumber << " and " << secondNumber << " is : " << firstNumber / secondNumber << endl;
            break;

            default:
            cout << "Invalid operator selected" << endl;
            break;

            cout << "Do you want to continue ( y / n ) ?";
            cin >> choiceSelector;

            if ( choiceSelector == 'y' || choiceSelector == 'Y' )
            {
                goto decisionMaker;
            }

        }
}
#include<iostream>
using namespace std;

int main()
{
    int number;
    int factorial = 1;

    cout << " ENter fact Num : ";
    cin >> number;

    for ( int i = 0; i <=number ; i ++)
    {
        factorial  = number * i;
        cout << factorial << endl;
    }
}
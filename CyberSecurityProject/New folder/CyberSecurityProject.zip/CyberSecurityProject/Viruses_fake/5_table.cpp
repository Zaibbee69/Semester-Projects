#include<iostream>
using namespace std;

int main()
{
    int number = 5;
    int multiple;
    for ( int i = 1; i <=10 ; i ++)
    {
        multiple  = number * i;
        cout << multiple << endl;
    }
}
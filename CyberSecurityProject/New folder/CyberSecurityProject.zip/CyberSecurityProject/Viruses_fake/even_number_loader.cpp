#include<iostream>
using namespace std;

// Prompt the user for a number and prints them upto that number 
int main()
{
    int even_limit;
    int even_number;

    cout << "Enter your number limit : ";
    cin >> even_limit;

    for ( int i = 0 ; i <= even_limit ; i ++ )
    {
        if ( i % 2 == 0 )
        {
            cout << i << endl;
        }
        
    }
}
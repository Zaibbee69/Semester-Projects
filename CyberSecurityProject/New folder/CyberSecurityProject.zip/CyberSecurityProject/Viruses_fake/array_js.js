let iceCreamFlavours = ["vanilla" , "strawberry" , "chocolate" , "pistachio"];
console.log(iceCreamFlavours);
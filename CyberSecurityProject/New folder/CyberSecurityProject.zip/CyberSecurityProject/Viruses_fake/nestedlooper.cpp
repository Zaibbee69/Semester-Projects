#include<iostream>
using namespace std;

int main ()
{
    int n;

    cout << "Enter a number: ";
    cin >> n;

    if ( n > 0 )
    {
        if ( n > 2 )
        {
            cout << "aaloooo" << endl;
        }
        else if ( n == 0 )
        {
            cout << "number is equal to zero";
        }
        else
        {
            cout << "Number is whatever";
        }
    }
    else
    {
        cout << "anday walla burger";
    }
}
#include<iostream>
using namespace std;

int main()
{
    int x;
    for (  x = 0 ; x != 123;)
    {
        cout << "Enter a numnber";
        cin >> x;
    }
    cout << x << "YAY" << endl;
}
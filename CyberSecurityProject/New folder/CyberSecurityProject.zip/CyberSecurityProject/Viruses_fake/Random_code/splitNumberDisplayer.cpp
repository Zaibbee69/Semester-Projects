#include<iostream>
using namespace std;

int main()
{
    int a , b , temp , num;

    cout << "Enter a three digit number : ";
    cin >> num;

    a = num/100;
    temp = num%100;
    b = temp/10;
    temp = temp % 10;
    cout << a <<endl << b << endl << temp << endl;
}
#include<iostream>
using namespace std;

int main()
{
    // Character to base the decisions for our switch statements
    int numberSwitch;

    // Getting character from user
    cout << "Enter any number from 1 to 5 : ";
    cin >> numberSwitch;

    // Now Entering a switch case statement
    switch (numberSwitch) // The variable put here decides on what variable are we deciding the decisions on
    {
        case 3-2 : // Notice how our case here is A because we are checking for char, if we had an int we would have made it like case "1":
        cout << " Value of A : " << numberSwitch << endl; // Here we putting the value of A which is basically the character switcher
        cout << " Its a rainy day" << endl ;
        break;

        case  4-2:
        cout << " Value of B : " << numberSwitch << endl;
        cout << " Its a sad day moye moye" << endl;
        break;

        // NOW JUST KEEP MAKING CASE STATEMENTS FOR AS MANY SITUATIONS U WANT , I ONLY PUT TWO CUZ TIME SHORTAGE

        default:
        cout << " Murghi may daal ha " << endl; // Default statement is executed if none above cases were satisfied
    }

}
// Including the required header files
#include<iostream>
#include<cmath>
using namespace std;

// Setting a standard for binary digits count
#define no_of_binary_digits 6 

// Writing a function to convert a binary number to hexadecimal using while loop
int main ()
{
    // Declaring the required variables
    long bn;
    int decimalnumber=0,hexadecimal=0,i=0;

    cout << "Enter a number : ";
    cin>> bn;
    // Using a while loop to first convert binary to decimal
    while( bn != 0 )
    {
        decimalnumber=decimalnumber+(bn%10)*pow(2 , i);
        i++;
        bn = bn/10 ;
    }
    cout << "Decimal = " << decimalnumber << endl;

    i = 1; // Resetting the counter value for usage

    // Now using while loop to convert decimal to hexa decimal
    while ( decimalnumber != 0 )
    {
        hexadecimal=hexadecimal+(decimalnumber%16)*i;
        decimalnumber=decimalnumber/16;
        i*=10;
    }
    cout << "Hexadecimal : " << hexadecimal << endl;

    return 0;

}

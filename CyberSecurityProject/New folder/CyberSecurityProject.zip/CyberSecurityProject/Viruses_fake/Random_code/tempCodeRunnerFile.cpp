// Including the required header files
#include<iostream>
#include<cmath>
using namespace std;

// Setting a standard for binary digits count
#define no_of_binary_digits 6 

// Writing a function to convert a binary number to hexadecimal using while loop
int main ()
{
    // Declaring the required variables
    unsigned long binary_number = 110011; 
    unsigned long decimal_number = 0;
    int decimal_holder;
    unsigned long hexadecimal_number = 0;
    int hexadecimal_holder;
    int reminder;
    int counter = 0;
 
    // Using a while loop to first convert binary to decimal
    while( counter < no_of_binary_digits )
    {
        reminder = binary_number % 10; // First getting the last digit of the binary number
        decimal_holder = reminder * pow(2 , counter); // Now making that values hexa i.e (1x2^0)...
        decimal_number += decimal_holder; // Adding the hexa value to decimal number
        binary_number /= 10; // Now just cutting of the last digit of the bn i.e if 110011 then it 11001
        counter ++; // Incrementing counter
    }
    cout << "Decimal = " << decimal_number << endl;

    counter = 0; // Resetting the counter value for usage

    // Now using while loop to convert decimal to hexa decimal
    while ( counter < decimal_number )
    {
        reminder = decimal_number % 16; // This time dividing by 16 for hexa decimal base 16
        hexadecimal_holder = reminder * pow(10 , counter);
        hexadecimal_number += hexadecimal_holder;
        decimal_number /= 16;
        counter ++;
    }
    cout << "Hexadecimal : " << hexadecimal_number << endl;

}

#include <iostream>
using namespace std;
int main () {
int a = 1, b = 1 , d = 1;
int c = ++a; 
d = ++ a * ++ b * c++; 
cout<<a<<" "<<b<<endl;
cout<<c<<" "<<d<<endl;
return 0;
}

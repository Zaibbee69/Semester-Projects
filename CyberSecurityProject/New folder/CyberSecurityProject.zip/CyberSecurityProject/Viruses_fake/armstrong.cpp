#include<iostream>
using namespace std;
int main() {
int num, rem, sum = 0, n; 
cout<<"Enter a number: ";
cin>>num;
n = num;
    while(n!=0)
    {	   
    rem = n % 10;
    sum = sum + (rem * rem * rem);
    n = n/10;
    }	     
	if (sum == num)
	cout<<num<<" is an Armstrong number";
	else
	cout<<num<<" is not an Armstrong number";         
return 0; } 
binary = 1001100

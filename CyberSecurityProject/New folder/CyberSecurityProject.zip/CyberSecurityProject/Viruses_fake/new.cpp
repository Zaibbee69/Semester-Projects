// Including the required the header files
#include<iostream>
using namespace std;

// Write a program to find the average of N numbers using while loop
int main ()
{
    // Declaring the required variables
    int N;
    int number;
    int sum = 0;
    int counter = 1;
    float average;

    // Getting the number from user
    cout << "Enter the number of terms to find average : " << endl;
    cin >> N;

    // Now using a while loop
    while ( counter <= N )
    {
        cout << "Enter your " << counter << " number : " << endl;
        cin >> number;
        sum += number;
        counter ++;
    }

    // Now finding average
    average = sum / N;
    cout << "Average is : " << average << endl;

    // Exiting function
    return 0;
}